-- 테이블 생성(CREATE TABELE)

/*
	SQL 작성 시 값이 아닌 것들은 대소문자를 구분하지 않는다.
	create table 테이블명 (
		컬럼명  테이터타입(크기), 	
		컬럼명  테이터타입(크기), 	
		컬럼명  테이터타입(크기),
		....
		컬럼명  테이터타입(크기)
	);
	-- 대소문자 구분 하지 않음...	
	create Table Tb_board
	CREATE tABLE tB_BOARD
	-- 내부적으로 테이블명과 컬럼명은 별도의 작업을 하지 않는 이상
	-- 대문자로 관리가 됨...
	
	-- 테이블명에 많이 사용되는 형태..
	T_업무, TB_업무, T업무관련키워드_업무명(TH_..., TC_...)
	
	테이블명, 컬럼명은 단어와 단어가 이어질때 "_"를 사용
*/
create table tb_board (
	no number(6),
	title varchar2(200),
	writer varchar2(30),
	content varchar2(4000),
	reg_date date
);

-- 유저가 가지고 있는 테이블 목록 확인
select *
  from tab;

-- 테이블 삭제하기(drop table 테이블명)
drop table TB_BOARD;

-- 휴지통에 들어간 테이블 완전 삭제
purge recyclebin;

-- 휴지통에 들어가지 않고 완전 삭제하기
drop table TB_BOARD purge;

-- 테이블의 만들어진 구조 확인하기
desc 테이블명

desc employees;

-- 제약조건
/*
   제약조건 방식에 따른 종류 : 테이블 레벨, 컬럼 레벨 
  ------------------------------------------------------ 
   테이블 레벨 제약조건 설정 : 컬럼의 선언 끝난다음 제약조건 설정
  create table ... (
  	  컬럼 ...,
  	  컬럼 ...,
  	  컬럼 ...,
  	  제약조건 설정.. 
  ); 
   컬럼 레벨 제약조건 설정 : 컬럼이 선언 될 때 같이 설정함	 	 
  create table ... (
  	  컬럼 ... 제약조건 설정,
  	  컬럼 ... 제약조건 설정,
  	  컬럼 ...제약조건 설정
  ); 
  ------------------------------------------------------ 
  - 제약조건의 종류
    1. PK : Primary Key
       - 하나의 테이블에는 로우 데이터를 구분하는 데이터가 존재 
       - 하나의 테이블에 하나만 존재
       - 하나의 PK는 여러개의 컬럼을 묶어서 사용할 수 있음
         (테이블 레벨 형식만 가능)
       - 데이터가 반드시 입력되어야 하고(Not Null) 
               중복된 데이터가 입력 될 수 없다.(Unique)
       - Not Null + Unique        
    2. NN : Not Null
       - 무조건 값이 입력되어야 한다. 
    3. UN : UNIQUE
       - 값이 중복되지 않는다.
    4. CK : Check
       - 사용자가 입력하는 값을 체크
       - gender char(1) check gender in ('f', 'm')   
    5. FK : Foreign Key
       - 다른 테이블의 값을 참조
       
    디폴트값 : 값이 입력되지 않은 경우 기본적으로 설정할 값
   - 컬럼  default 값    
   
   sysdate : 현재 시간 정보를 반환하는 함수
 */
create table tb_board (
	no number(6) primary key,
	title varchar2(200) not null,
	writer varchar2(30) not null,
	content varchar2(4000) not null,
	reg_date date default sysdate
);

-- pk 테스트
insert into tb_board(no) values(1);
insert into tb_board(no) values(1);  -- unique constraint 조건 위배

-- 테이블에 입력된 데이터 조회
select * from tb_board;

insert into tb_board(no, title, writer, content) 
values(1, '제목', '글쓴이', '내용');

-- 테이블 이름 변경 : rename A(원래 이름) to B(변경할 이름)
rename tb_board to tb_board_bak;

rename tb_board_bak to tb_board;

-- 컬럼명 변경하기
-- alter table 테이블명
-- rename column A to B;

alter table tb_board
rename column title to title2;

alter table tb_board
rename column title2 to title;

select * from tb_board;

insert into tb_board(no, title, writer, content) 
values(2, '제목', '글쓴이', '내용');

-- 테이블의 데이터를 복구 불가능하게 삭제
-- truncate table 테이블명;
truncate table tb_board;
select * from tb_board;

-- DML
-- insert, update, delete
-- 컬럼명을 지정하지 않은 경우 테이블의 모든 컬럼에 값을 입력해야 함
insert into 테이블명 values(값1, ...);  -- 참고
insert into 테이블명(컬럼명, ..) values(값1, ...);

insert into tb_board(no, title, writer, content)
values (3, 'title', 'writer', 'content');

insert into tb_board(no, title, writer, content)
values (3, 'title', 'writer', 'content');

insert into tb_board
values (3, 'title', 'content', 'writer', sysdate);

select * from tb_board;

-- update
update 테이블명
   set 컬럼명 = 변경할값;

update tb_board
   set title = '수정제목';
   
select * from tb_board;  

insert into tb_board(no, title, writer, content)
values(4, '제목', '글쓴이', '내용');

update tb_board
   set title = '변경된제목';

-- 특정 데이터만 수정
update 테이블명
   set 컬럼명 = 변경할값
 where 컬럼명 = 비교값;
 
-- 글번호가 4번인 게시물의 제목을 '조건변경'으로 변경하시오 
update tb_board
   set title = '조건변경',
       content = '내용변경'
 where no = 4;  
 
-- delete : 데이터 삭제
delete [from] 테이블명;   -- 전체 데이터 삭제

delete [from] 테이블명    -- 조건이 일치하는 데이터만 삭제
 where 컬럼 = 값;
 
delete 
  from tb_board
 where no = 3;
 
select * 
  from tb_board; 
 
/* ---------------------------------------
   SELECT 절
   1. *
   2. 산술연산
   3. alias
   4. 합성연산자 	 
   ---------------------------------------	
 */   

-- * : 모든 컬럼들 출력  
select *
  from tb_board;

select *
  from employees;
  
-- 특정 컬럼의 데이터만 보기
select last_name, salary  
  from employees;

-- 존재하지 않는 컬럼을 호출시 에러
select last_name, salary, sal  
  from employees;

select last_name, salary, 100, 'aaa', sysdate  
  from employees;
  
-- 산술연산
select last_name, salary, salary * 12 + 1000  
  from employees; 
   
-- alias : 컬럼의 별칭, 테이블의 컬럼명 변경(X)
-- 컬럼명  별칭,  컬럼명  as  별칭
select employee_id 사번, last_name as 이름, salary as 급여
  from employees;
  
select last_name,
       case when salary >= 20000 then '고급기술직원'
            when salary >= 10000 then '중급기술직원'
            else '초급기술직원'
        end as skill_type
  from employees;      
  
-- 합성연산자(||)  :  자바의 "+" 연산자와 동일한 기능 

-- ??? 사원의 사번은 ??? 입니다. 
select last_name || ' 사원의 사번은 ' || employee_id || '입니다.'
       as info
  from employees;
  
/* ---------------------------------------
   WHERE 절  : 전체 데이터의 범위를 줄여준다.
   ---------------------------------------	
 */   
-- 사원의 정보를 출력합니다. 
-- 단, 110번 부서에 근무하는 사원의 정보만 출력 
select *
  from employees
 where department_id = 110;
  
-- 사원의 정보를 출력합니다. 
-- 단, 급여가 10000 이상인 사원의 정보만 출력 
select *
  from employees
 where salary >= 10000;
  
-- 사원의 정보를 출력합니다. 
-- 단, 부서가 100번 부서이면서 
-- 급여가 10000 이상인 사원의 정보만 출력 
select *
  from employees
 where department_id = 100
   and salary >= 10000;
 
-- 사원의 정보를 출력합니다. 
-- 단, 부서가 100번  이거나 110번 부서인 사원의 정보만 출력 
select *
  from employees
 where department_id = 100
    or department_id = 110;
  
-- 사원의 정보를 출력합니다. 
-- 단, 부서가 90번 이거나 100번 부서이면서  
-- 급여가 10000 이하인 사원의 정보만 출력
select *
  from employees
 where department_id = 90
    or department_id = 100
   and salary <= 10000; 

select *
  from employees
 where (department_id = 90 or department_id = 100)
   and salary <= 10000; 
   
select *
  from employees
 where department_id in (90, 100)
   and salary <= 10000; 
   
   
   
    
/*
   SQL 연산자
   1. 컬럼명 between a and b :  a 부터 b 사이의 데이터 
   2. 컬럼명 in (값1, 값2, ...) : 컬럼의 값이 리스트와 같은 값인지
   3. 컬럼명 like '포멧문자' : 특정한 형태인지 	
   4. 컬럼명 is null  :  널값인지 체크
 */  
-- 사원의 급여가 10000이상이고 15000이하인 사원의 정보를 출력
select *
  from employees
 where salary >= 10000
   and salary <= 15000;

-> BETWEEN 연산자 활용

select *
  from employees
 where salary between 10000 and 15000;
 
-- 사원의 부서가 30, 40, 50, 60, 70, 80, 90, 100인 사원들의 
-- 정보를 출력
select *
  from employees
 where department_id = 30
    or department_id = 40
    ....;
    
select *
  from employees
 where department_id in (30, 40, 50, 60, 70, 80, 90, 100); 

-- like 연산자 : _(한글자), %(0개 이상의 문자)
-- where last_name like 'a%' -> a, abcd, aaa, ba(x)  
select *
  from employees
 where last_name like 'K%';
 
-- 이름(last_name)이 4자인 사원의 정보를 출력
select *
  from employees
 where last_name like '____';
 
-- 사원의 이름의 두번째 글자가 'h'인 사원들의 정보를 출력
select *
  from employees
 where last_name like '_h%';
 
-- 이메일의 첫글자가 'D'이고 끝글자가 'T'인 사원의 정보 출력
select *
  from employees
 where email like 'D%T';
 
-- 검색어가 들어간 모든 데이터를 조회 
like '%검색어%' 
 
-- 이름이 'King'인 사원의 정보를 출력
select *
  from employees
 where last_name = 'King';
 
-- null 이란? 미정의 값
-- null과의 비교연산은 false 를 반환
-- null과의 산술연산은 null 을 반환
select *
  from employees
 where commission_pct = null;
 
select *
  from employees
 where commission_pct is null;
 
select *
  from employees
 where commission_pct is not null;
 
 
 



  
  
   
   
   
   