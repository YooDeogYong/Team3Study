select last_name, department_id
  from employees;
  
  
select department_id, department_name 
  from departments; 
  
-- 사원이름, 부서번호, 부서이름
-- employees  : last_name, department_id
-- departments: department_id, department_name 
-- 에러 : 컬럼이 2개 이상의 테이블에 포함될 경우
--        컬럼명 앞에 테이블명을 줘야한다.
select last_name, department_id, department_name
  from employees, departments;
  
-- 카테시안 프로덕트(Cartesian Product)  
select last_name, 
       employees.department_id, 
       department_name
  from employees, departments;  
  
-- 테이블간의 증거조건을 설정
-- 증거조건 : 테이블수 - 1   
select last_name, 
       employees.department_id, 
       department_name
  from employees, departments
 where employees.department_id = departments.department_id;      
 
-- 필수는 아니지만 쿼리문의 가독성을 좋게하기 위해
-- 반드시 컬럼명 앞에 테이블을 알려준다. 
select employees.last_name, 
       employees.department_id, 
       departments.department_name
  from employees, departments
 where employees.department_id = departments.department_id; 
 
-- 테이블 Alias 활용하기
-- 테이블 Alias 설정 : 테이블명 별칭 
-- Equi Join( 연산자 = 을 활용하는 조인 )
select e.last_name, 
       e.department_id, 
       d.department_name
  from employees e, departments d
 where e.department_id = d.department_id;      
 
-- 각 사원의 직무(job_id)에 따른 최소 급여와 최대 급여를 화면에 출력
-- (이름, 직무명, 최소급여, 최대급여)
select e.last_name, j.job_title, j.min_salary, j.max_salary
  from employees e, jobs j
 where e.job_id = j.job_id;
 
-- Canada에 근무하는 사원의 도시명, 부서명, 사원명을 출력하시오
-- (city, department_name, last_name) 
select e.last_name, d.department_name, l.city  
  from employees e, departments d, locations l, countries c
 where e.department_id = d.department_id
   and d.location_id = l.location_id
   and l.country_id = c.country_id
   and c.country_name = 'Canada';   
 
 
 
create table salgrade (
    grade char(1),
    min_sal number(6),
    max_sal number(6)
);

insert into salgrade values ('1', 20000, 100000);

insert into salgrade values ('2', 10000, 19999);

insert into salgrade values ('3', 6000, 9999);

insert into salgrade values ('4', 3000, 5999);

insert into salgrade values ('5', 1, 2999);

select *
  from salgrade;
  
commit;
  
-- non equi join( = 연산자 이외를 사용 )
select e.last_name, e.salary, s.grade
  from employees e, salgrade s
 where e.salary between s.min_sal and s.max_sal;
 
-- Self Join(물리적 테이블 1개, 논리적 테이블 2개 이상)
-- 각 사원의 관리자의 이름을 출력
select e.employee_id, e.last_name 사원명, m.last_name 관리자명
  from employees e, employees m
 where e.manager_id = m.employee_id
 order by e.employee_id;
 
select employee_id, last_name, manager_id
  from employees; 

-- outer join ( 조인조건을 만족하지 않더라도 출력 )
-- (+) 결과가 모자른 쪽에 붙인다.
select e.employee_id, e.last_name 사원명, 
       nvl(m.last_name, '관리자 없음') 관리자명
  from employees e, employees m
 where e.manager_id = m.employee_id(+)
 order by e.employee_id;

-- Oracle 9i 부터 
select e.last_name, e.department_id, d.department_name
  from employees e, departments d; 
  
select e.last_name, e.department_id, d.department_name
  from employees e
 cross join departments d;
 
select e.last_name, 
       e.department_id, 
       d.department_name
  from employees e, departments d
 where e.department_id = d.department_id;   
 
-- Equi Join 대체
-- inner join on 
-- 테이블 inner join 테이블 on 증거조건  
select e.last_name, 
       e.department_id, 
       d.department_name
  from employees e 
 inner join departments d
    on e.department_id = d.department_id;
    
    
select e.last_name, j.job_title, j.min_salary, j.max_salary
  from employees e
 inner join jobs j
    on e.job_id = j.job_id;   
    
    
select e.last_name, d.department_name, l.city  
  from employees e 
 inner join departments d
    on e.department_id = d.department_id
 inner join locations l
    on d.location_id = l.location_id
 inner join countries c
    on l.country_id = c.country_id
 where c.country_name = 'Canada'; 
 
select e.last_name, e.salary, s.grade
  from employees e
 inner join salgrade s
    on e.salary between s.min_sal and s.max_sal;  
    
select e.employee_id, e.last_name 사원명, m.last_name 관리자명
  from employees e
 inner join employees m
    on e.manager_id = m.employee_id
 order by e.employee_id;

-- (full | left | right) outer join
select e.employee_id, e.last_name 사원명, 
       nvl(m.last_name, '관리자 없음') 관리자명
  from employees e
  left outer join employees m
    on e.manager_id = m.employee_id
 order by e.employee_id; 

-- SET 연산자

create table tc_seta (
    no number,
    data varchar2(2)
);

create table tc_setb (
    no number,
    data varchar2(2)
);

insert into tc_seta values(1, 'a');
insert into tc_seta values(2, 'b');
insert into tc_seta values(3, 'c');
insert into tc_seta values(4, 'd');

insert into tc_setb values(3, 'c');
insert into tc_setb values(4, 'd');
insert into tc_setb values(5, 'e');
insert into tc_setb values(6, 'f');

select no, data
  from tc_setb;

select no, data
  from tc_seta
 union all 
select no, data
  from tc_setb;

select no, data
  from tc_seta
 union  
select no, data
  from tc_setb;

select no, data
  from tc_seta
 intersect  
select no, data
  from tc_setb;

select no, data
  from tc_seta
 minus
select no, data
  from tc_setb;
 
select department_name
  from departments
 union all 
select last_name
  from employees; 
-- 같은 위치의 컬럼은 데이터 타입이 동일해야 함 
select department_id
  from departments
 union all 
select last_name
  from employees;  
 
-- select 절의 컬럼의 개수가 동일해야 함
select department_id
  from departments
 union all 
select employee_id, last_name
  from employees;   
-- Order by 절은 set 절의 가장 마지막에 선언되어야 한다.
select department_id
  from departments
 order by department_id 
 union all 
select employee_id, last_name
  from employees;  
  
select last_name 사원명, salary 급여
  from employees 
 union all 
select 'total_sum', sum(salary)
  from employees;  
  
-- 서브쿼리(subquery)
-- Chen 사원의 부서번호를 출력
select department_id
  from employees
 where last_name = 'Chen';              
 
-- Chen 사원과 같은 부서에 근무하는 사원들의 정보를 출력
select *
  from employees
 where department_id = (Chen 사원의 부서번호);
 
select *
  from employees
 where department_id = (select department_id
                         from employees
                        where last_name = 'Chen'); 

-- SingleRowSubquery : 결과행의 수가 1개인 것
select *
  from employees
 where job_id = (select job_id
                  from employees
                 where last_name = 'Chen'); 

-- King 사원과 같은 부서에 근무하는 사원들의 정보를 출력
select *
  from employees
 where department_id = (select department_id
                         from employees
                        where last_name = 'King');

select *
  from employees
 where department_id = (80, 90);

-- MultiRowSubquery : 결과행의 수가 2개 이상인 것
-- IN, ANY, ALL
select *
  from employees
 where department_id in (select department_id
                          from employees
                         where last_name = 'King');

select *
  from employees
 where salary >ANY (select salary 
                     from employees
                    where department_id = 30);

select *
  from employees
 where salary > (select min(salary) 
                 from employees
                where department_id = 30);
                
                
select *
  from employees
 where salary >ALL (select salary 
                     from employees
                    where department_id = 30);
                    
-- 각 부서에서 가장 작은 급여를 받는 사원의 정보를 출력
select *
  from employees
 where salary in (부서에서 가장 작은 급여);
 
select department_id, salary, last_name
  from employees
 where salary in (select min(salary) 
                   from employees
                  group by department_id)
 order by department_id;
                   
-- MultiColumnSubquery (쿼리의 실행결과가 여러개의 컬럼을 반환) 
select department_id, salary, last_name
  from employees
 where (department_id, salary) in (select department_id, min(salary) 
                                   from employees
                                  group by department_id)
 order by department_id;                    
 
-- insert 문에서의 서브쿼리
insert into tb_board(no, title, writer, content)
values (
    (select nvl(max(no), 0) + 1 from tb_board), 'a', 'w', 'c'
); 

-- select 절의 서브쿼리
select e.last_name, d.department_name
  from employees e
 inner join departments d
    on e.department_id = d.department_id;
    
select e.last_name, 
       (select department_name from departments 
         where department_id = e.department_id) 
  from employees e;
  
-- from 절에서의 서브쿼리(Inline view)
select a.employee_id, a.last_name
  from (select employee_id, last_name
          from employees
         where department_id = 30
           and salary > 10000) a;  
                        
-- Top-N Subquery
-- rownum : 더미컬럼, 데이터 출력 시 순차적으로 숫자를 증가
select employee_id, last_name, salary
  from employees;
  
select rownum, employee_id, last_name, salary
  from employees;  
  
select rownum, employee_id, last_name, salary
  from employees
 where rownum <= 5;
 
-- 상위 급여 5명을 출력하시오
select rownum, employee_id, last_name, salary
  from employees
 where rownum <= 5
 order by salary desc;
  
                      
select rownum, employee_id, last_name, salary
  from (select employee_id, last_name, salary
          from employees
         order by salary desc)
 where rownum <= 5;
 
select rownum, employee_id, last_name
  from employees
 where rownum = 2;
 
 
select rownum, a.hire_date, a.*
  from (select *
          from employees
         order by hire_date desc) a
 where rownum between 1 and 5;        
 
select b.*
  from (
        select rownum rnum, a.*
          from (select *
                  from employees
                 order by hire_date desc) a    
       ) b 
 where rnum between 6 and 10;                  