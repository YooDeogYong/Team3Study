/*
	order by : 정렬
	내림차순(desc), 오름차순(asc)
	desc 또는 asc를 표시하지 않으면 기본적으로 오름차순이 적용
	
	order by (표현식 | 컬럼명) [ASC | DESC]
	
	order by no;      -- asc 디폴트 적용
	order by no desc; 
	order by department_id, salary desc;
 */
-- 사원의 정보를 출력합니다.
-- 단, 급여가 높은 사원부터 출력합니다.
from -> 사원(employees)
select -> 사원의 정보(*)
where -> 없음
order by -> 급여가 높은 사원부터(salary desc)

select *
  from employees
 order by salary desc;

-- 사원의 정보를 부서번호 순으로 출력하시오
select *
  from employees
 order by department_id;

-- 사원의 정보를 부서번호 순으로 출력하시오. 같은 부서번호에서는 
-- 사원의 이름으로 정렬하시오.
select *
  from employees
 order by department_id, last_name;
 
-- 사원의 연봉으로 정렬하시오
-- 연봉은 급여 * 15 입니다.
select last_name, salary * 15 as year_sal
  from employees
 order by salary * 15; 
 
select last_name, salary * 15 as year_sal
  from employees
 -- where year_sal > 10000 (오류 - where 절은 select 절 보다 먼저 수행됨 
 order by year_sal; 
 
-- distinct : 중복된 데이터를 걸러준다.
select department_id
  from employees;

select distinct department_id
  from employees;

select distinct department_id, last_name
  from employees;
  
/*  
	GROUP BY : 데이터 그룹핑하기
	- 데이터들을 작은 소그룹으로 묶어준다.
	- 통계 정보를 구하려고 할 때 주로 사용된다.
	- 그룹함수와 같이 사용이 많이 된다.
	  1) SUM, MAX, MIN, AVG, COUNT
	  2) 여러개의 데이터를 입력받아 하나의 결과를 반환  
 */ 
-- 전체 사원의 총 급여액을 구하시오
select count(salary), sum(salary), max(salary), min(salary),
       avg(salary)
  from employees;
  
-- 100번 부서에 속한 사원의 총 급여액을 구하시오
select sum(salary)
  from employees
 where department_id = 100;
  
-- 100번 부서에 속한 사원의 총 급여액을 구하시오
-- 단, 화면에 출력은 부서번호와 총급여액을 보여주어야 한다.
-- 오류(그룹함수는 1번만 출력하려 한다. 부서번호는 여러번 출력하려 한다.)
select department_id, sum(salary)   
  from employees
 where department_id = 100;
  
select max(department_id), sum(salary)   
  from employees
 where department_id = 100;
  
-- 논리적 버그 발생.... 
select max(department_id), sum(salary)   
  from employees
 where department_id in (100, 110);
  
-- GROUP BY 연습
select *
  from TB_GROUP;

select job_id, count(*)
  from tb_group
 group by job_id;
 
select dept_id, count(*)
  from tb_group
 group by dept_id;
 
select dept_id, job_id, count(*)
  from tb_group
 group by dept_id, job_id;
 
-- 각 부서별로 부서에 속해있는 사원의 인원수와 최대 급여, 최소급여
-- 평균 급여를 화면에 출력하시오
select department_id, count(*), max(salary), min(salary),
       avg(salary)
  from employees 
 group by department_id;
 
 
 
-- 각 부서별로 부서에 속해있는 사원의 인원수와 최대 급여, 최소급여
-- 평균 급여를 화면에 출력하시오
-- 최대급여가 높은 부서부터 출력  
select department_id, count(*), max(salary) max_sal, 
       min(salary), avg(salary)
  from employees 
 group by department_id
 order by max_sal desc;
  
-- 각 부서별로 부서에 속해있는 사원의 인원수와 최대 급여, 최소급여
-- 평균 급여를 화면에 출력하시오
-- 최대급여가 높은 부서부터 출력  
-- 단, 최대급여가 10000 이상인 부서만 출력  
select department_id, count(*), max(salary) max_sal, 
       min(salary), avg(salary)
  from employees
 where max(salary) > 10000 -- 에러(그룹함수는 where에 사용 불가)
 group by department_id
 order by max_sal desc;
  
select department_id, count(*), max(salary) max_sal, 
       min(salary), avg(salary)
  from employees
 group by department_id
having max(salary) > 10000
 order by max_sal desc;
  
-- 각 부서별로 부서에 속해있는 사원의 인원수와 최대 급여, 최소급여
-- 평균 급여를 화면에 출력하시오
-- 최대급여가 높은 부서부터 출력  
-- 단, 최대급여가 10000 이상인 부서만 출력하고  
--     100번보다 큰 부서는 제외한다.
select department_id, count(*), max(salary) max_sal, 
       min(salary), avg(salary)
  from employees
 group by department_id
having max(salary) > 10000
   and department_id <= 100
 order by max_sal desc;  
  
select department_id, count(*), max(salary) max_sal, 
       min(salary), avg(salary)
  from employees
 where department_id <= 100
 group by department_id
having max(salary) > 10000
 order by max_sal desc;  
  
-- 단일행 함수 : 문자형 함수
select upper('a')
  from employees;
  
-- 데이터가 하나만 존재하고 컬럼이 하나만 있는 더미테이블 : dual
select upper('a'), lower('A'), concat('홍길동', ' 의적')
  from dual;
  
select first_name, last_name,
       concat(upper(last_name), lower(first_name)),
       upper(last_name) || lower(first_name)
  from employees;

-- he  
select substr('hello', 1, 2)
  from dual;
  
-- 2017, 08, 17  
select substr('2017-08-17', 1, 4),  
       substr('2017-08-17', 6, 2),
       substr('2017-08-17', 9, 2)
  from dual;     
  
select lpad('test', 10, '*'), rpad('test', 10, '*')  
  from dual;

select lpad(last_name, 10, '*')  
  from employees;
  
  
select 'hi hello sql', 
       translate('hi hello sql', 'el', 'am'),
       replace('hi hello sql', 'el', 'am')
  from dual;

-- hong *****won  
select 'hong 11900won', 
       translate('hong 11900won', '0123456789', '**********')
  from dual;
  
select 'hello', length('hello')
  from dual;
  
-- 숫자형 함수  
select abs(100), abs(-100)
  from dual;
  
select ceil(1.3), floor(1.3)
  from dual;

--            -1        0         1 
select sign(-11), sign(0), sign(11)
  from dual;
  
select round(73.727), trunc(73.727)
  from dual;

select round(73.727, 2), trunc(73.727, 2)
  from dual;

select round(73.727, -2), trunc(73.727, -2)
  from dual;

-- 날짜형 함수
select sysdate,
       add_months(sysdate, 1),
       add_months(sysdate, -1)
  from dual;

-- 사원들의 입사한지 1년째 되는 날을 출력하시오
select add_months(hire_date, 12)
  from employees;
  
select trunc(months_between(sysdate, hire_date))
  from employees; 
 
select last_day(sysdate)
  from dual;
  
-- 날짜 + 숫자 = 날짜
-- 날짜 - 숫자 = 날짜
-- 날짜 - 날짜 = 숫자  
select sysdate, sysdate + 7, sysdate - 7, sysdate + 5/24
  from dual;
  
select sysdate - hire_date
  from dual;
-- 변환형 함수 : to_char, to_date, to_number
-- to_char(날짜, '패턴) : 날짜를 문자로 변경  

SimpleDateFormat sdf = new SimpleDateFormat(
	"yyyy-MM-dd HH:mm:ss"
); 
Date d = sdf.parse("2017-11-10 11:11:11");

String result = sdf.format(new Date());

select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'),
       to_char(sysdate, 'yyyy-mm-dd'),
       to_char(sysdate, 'hh24:mi:ss'),
       to_char(sysdate, 'mm')
  from dual;     
  
select to_date('2017-11-11 11:11:11', 'yyyy-mm-dd hh24:mi:ss'),
       to_date('2017-11-11', 'yyyy-mm-dd'),
       to_date('13:11:10', 'hh24:mi:ss'),
       to_date('02', 'mm')
  from dual;     
  
select *
  from tb_board
 where reg_date between to_date('2017-01-01', 'yyyy-mm-dd')
                    and to_date('2017-02-01 23:59:59', 'yyyy-mm-dd hh24:mi:ss')
                    
                    
insert into tb_board(no, title, writer, content, reg_date)
values (6, 'a', 'b', 'c', to_date('2016-11-09 11:11:11', 'yyyy-....'))
  
-- to_char(숫자, '패턴) : 숫자를 문자로 변경
-- 패턴문자 : 9(자리수), 0(자리수)
select to_char(8761294763),
	   8761294763 || '', 	
       to_char(8761294763, '999,999,999,999'),
       to_char(8761294763, '000,000,000,000')
  from dual;     

select to_number('1234'), to_number('1,234', '9,999')
  from dual;

-- 사원중에서 5월에 입사한 사원들의 정보만 출력하시오
select *
  from employees
 where to_char(hire_date, 'mm') = '05';


-- 사원중에서 현재월과 같은 월에 입사한 사원들의 정보만 출력하시오
select *
  from employees
 where to_char(hire_date, 'mm') = to_char(sysdate, 'mm');

-- 기타형 함수
-- NVL : null 에 값을 입력
-- nvl(표현식 | 컬럼, '널일경우의 값')
select salary, commission_pct,
       salary + salary * commission_pct,
       salary + salary * nvl(commission_pct, 0)
  from employees;

-- 그룹함수는 null 값을 제외한다.  
-- 그룹함수중에 유일하게 null 값 처리를 하는 함수 : count(*)
select sum(commission_pct), count(commission_pct), count(*)
  from employees;
  
-- decode : 자바의 switch 문 같은 용도 
/*
   switch (job_id) {
	  case "IT_PROG":
	            개발자
	  case "2":
	      ...
  	  default:
  	      ...	
   }
*/   
select job_id,
       decode(job_id, 'IT_PROG', '개발자', 
                      'SA_MAN', '세일즈',
                      '평범한 직원')
  from employees;
  
/*
	if ~ else if ~ else 와 비슷한 구조
	같다 이외의 모든 비교가 가능
	
	case when 조건  then 처리할 값
	     when 조건  then 처리할 값
	     else 디폴트값
	 end     
 */  
select job_id,
       decode(job_id, 'IT_PROG', '개발자', 
                      'SA_MAN', '세일즈',
                      '평범한 직원'
       ) as decode_msg,
       case job_id when 'IT_PROG' then '개발자' 
                   when 'SA_MAN' then '세일즈' 
                   else '평범한 직원'
        end as case_msg, 
       case when salary > 15000 then '고급 개발자' 
            when salary > 10000 then '중급 개발자' 
            else '초급 개발자'
        end as sal_type 
  from employees;  
  
-- 시퀀스 : 자동 고유번호 발번기
-- 이름규칙 : s_테이블명(tb_ 제외)_컬럼명  
create sequence s_board_no;

-- 시퀀스이름.nextval : 고유번호를 생성한다.
  
  
  


 
 



