package O1_basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Test04 {
	public static void main(String[] args) {
		Connection con = null;
//		Statement stmt = null; 
		PreparedStatement stmt = null; 
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", 
					"hr", "hr"
			);
			StringBuffer sql = new StringBuffer();
			sql.append("update tb_board ");
			sql.append("   set title = '변경제목', ");
			sql.append("       content = '변경내용' ");
			sql.append(" where no = 11 ");
			
//			stmt = con.createStatement();
//			int cnt = stmt.executeUpdate(sql.toString());

			stmt = con.prepareStatement(sql.toString());
			int cnt = stmt.executeUpdate();
			
			System.out.println(cnt + "개의 행이 변경됨");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}













