package O1_basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Test06 {
	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", 
					"hr", "hr"
			);
			StringBuffer sql = new StringBuffer();
			sql.append("select no, title, writer, reg_date ");
			sql.append("  from tb_board ");
			sql.append(" order by no desc ");
			
			stmt = con.prepareStatement(sql.toString());
			ResultSet rs = stmt.executeQuery();
			SimpleDateFormat sdf = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss"
			);
			List<Board> list = new ArrayList<>(); 
			while (rs.next()) {
				Board board = new Board();
				board.setNo(rs.getInt("no"));
				board.setTitle(rs.getString("title"));
				board.setWriter(rs.getString("writer"));
				board.setRegDate(rs.getTimestamp("reg_date"));
				list.add(board);
			}
			
			// 리스트의 내용을 화면에 출력한다.
			for (Board board : list) {
				System.out.printf(
						"%d\t%s\t%s\t%s\n", 
						board.getNo(), 
						board.getTitle(), 
						board.getWriter(),
						sdf.format(board.getRegDate())
				);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}








