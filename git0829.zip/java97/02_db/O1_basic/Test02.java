package O1_basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class Test02 {
	public static void main(String[] args) {
		Connection con = null;
		Statement stmt = null;
		PreparedStatement pstmt = null;
		try {
			// 드라이버 로딩 : ojdbc6.jar 파일안에 있는 클래스 이름
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 연결 가져오기
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", 
					"hr", "hr"
			);
			// SQL 작성하기
			StringBuffer sql = new StringBuffer();
			sql.append("delete ");
			sql.append("  from tb_board ");
			sql.append(" where no = 4 ");
			
			// 실행 객체 얻기(Statement, PreparedStatement)
//			stmt = con.createStatement();
			pstmt = con.prepareStatement(sql.toString());
			
			// SQL 실행하기
			// executeQuery  : select SQL 실행
			// executeUpdate : select 절 이외의 SQL 실행
//			int cnt = stmt.executeUpdate(sql.toString());
			int cnt = pstmt.executeUpdate();
			
			// 결과 처리
			System.out.println(cnt + "개의 행이 변경됨");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}






