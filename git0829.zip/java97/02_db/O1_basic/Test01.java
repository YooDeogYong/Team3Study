package O1_basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Test01 {
	public static void main(String[] args) {
		// 연결정보를 관리하는 인터페이스 객체
		Connection con = null;
		try {
			// 드라이버 로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("드라이버 로딩 성공");
			
			// 연결 가져오기
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE",
					"hr", "hr"
			);
			System.out.println("연결 성공 : " + con);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}












