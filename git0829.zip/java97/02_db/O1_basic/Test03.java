package O1_basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class Test03 {
	public static void main(String[] args) {
		// INSERT 
		// 번호 : 시퀀스 활용(s_board_no.nextval)
		// 제목 : JDBC 연습
		// 내용 : JDBC 데이터 입력
		// 글쓴이 : 이름...
		Connection con = null;
		Statement stmt = null;
		PreparedStatement pstmt = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", 
					"hr", "hr"
			);
			StringBuffer sql = new StringBuffer();
			sql.append("insert into tb_board( ");
			sql.append("    no, title, writer, content   ");
			sql.append(") values ( ");
			sql.append(     "s_board_no.nextval, 'JDBC 연습', '강사', 'JDBC 데이터 입력' ");
			sql.append(")  ");
			
			pstmt = con.prepareStatement(sql.toString());
			int cnt = pstmt.executeUpdate();
			System.out.println(cnt + "개의 행이 변경됨");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}		
	}
}
