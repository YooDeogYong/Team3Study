/*
 * final 의 세가지 용법
 *   - 변수 : 상수로 사용
 *   - 메서드 : 오버라이딩 금지
 *   - 클래스 : 상속 금지
 */
package day11;
/* final */ class FinalParent {
	public /* final */ void call() {}
}
class FinalSub extends FinalParent {
	public void call() {}
}
public class Test06 {
		
}








