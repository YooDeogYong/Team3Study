package day11.exam;

public abstract class Shape {
	public abstract void area();
}
