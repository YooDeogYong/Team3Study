package day11.b;

import day11.a.Test;

public class PackC extends Test {
	public PackC() {
		System.out.println(name);
		System.out.println(addr);
		/*
		System.out.println(pass);
		System.out.println(money);
		*/
	}
}
