package day11.b;

import day11.a.Test;

public class PackB {
	public static void main(String[] args) {
		Test t = new Test();
		System.out.println(t.name);
		/*
		// 서로다른 패키지는 public 만 가능
		System.out.println(t.addr);
		System.out.println(t.pass);
		System.out.println(t.money);
		*/
	}
}











