package day11;

import java.util.Random;

public class Quiz02 {
	public static void main(String[] args) {
		System.out.println("aaa");
		/*
		public class System {
			public static 참조타입 out = ?? 
		}
		 */
		
		
		
		int val = Integer.parseInt("100");
		/*
		public class Integer {
			public static int parseInt(String val) {
				??
			}
		}
		 */
		Random r = new Random();
		int num = r.nextInt(100);
		/*
		public class Random {
			public int nextInt(int bound) {
				??
			}
		}
		 */
	}
}








