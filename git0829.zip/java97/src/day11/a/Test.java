package day11.a;
public class Test {
	public String name;
	protected String addr;
	String pass;
	private int money;
}












