package day11.a;

public class PackA extends Test {
	public PackA () {
		System.out.println(name);
		System.out.println(addr);
		System.out.println(pass);
		// private 는 상속관계에 있더라도 사용 불가능
//		System.out.println(money);
	}
}
