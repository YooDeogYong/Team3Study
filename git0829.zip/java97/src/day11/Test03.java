/*
 * 생성자에서 하는 일
 * - 생성자에서 super 또는 this 의 호출구문을 찾는다.
 * - 만약, super 또는 this 가 존재하지 않으면 
 *   super() 코드를 자동 추가한다.
 */
package day11;
class Parent {
//	Parent() {}
	Parent(String name) {}
}
class Child extends Parent {
	Child() {
		super("test");
	}
	
	/*
	Child() {
		super();	
	}
	*/
}

public class Test03 {
	public static void main(String[] args) {
		
	}
}









