package day11;
				
class Person {
	String name;
	int age;
	public Person() {}
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public String toString() {
		return String.format("name=%s, age=%d", name, age);
	}
}

class Student extends Person {
	String no;  // 학번
	public Student() {}
	public Student(String name, int age, String no) {
		super(name, age);
		/*
		this.name = name;
		this.age = age;
		*/
		this.no = no;
	}
	public String toString() {
		return String.format("%s, no=%s", super.toString(), no);
	}	
}
public class Test02 {
	public static void main(String[] args) {
		Student s = new Student("홍길동", 33, "S01");
		System.out.println(s.toString());
	}
}











