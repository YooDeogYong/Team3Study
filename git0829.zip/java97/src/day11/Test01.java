package day11;
class Animal {
	String name;
	int age;
	public void eat() {
		System.out.println("먹다.");
	}
}
class Dog extends Animal {
	public void eat() {
		System.out.println(name + "이 먹는다.");
	}
}
public class Test01 {
	public static void main(String[] args) {
		Dog d = new Dog();
		d.name = "쫑";
		d.age = 3;
		d.eat();
	}
}













