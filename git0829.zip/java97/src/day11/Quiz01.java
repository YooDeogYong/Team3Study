package day11;
class ConsParent {
	ConsParent () { System.out.println(1); }
	ConsParent (int i) { System.out.println(2); }
	ConsParent (String n) { System.out.println(3); }
}
class ConsChild extends ConsParent {
	ConsChild() {
		this("test");
		System.out.println(4);
	}
	ConsChild(int i) {
		super("test");
//		this("test");
		System.out.println(5);
	}
	ConsChild(String n) {
		System.out.println(6);
	}
}
public class Quiz01 {
	public static void main(String[] args) {
		System.out.println("main start");
		ConsChild cc = new ConsChild();
		System.out.println("main end");
	}
}










