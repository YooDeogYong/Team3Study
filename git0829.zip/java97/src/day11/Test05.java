/*
 *   객체의 형변환 - 상속관계에서 발생
 *   
 *   명시적 형변환 
 *   - 자식 = (타입)부모
 *   
 *   묵시적 형변환
 *   - 부모 = 자식
 *   - 객체 변수가 접근 가능한 변수 또는 메서드는 자신의 클래스 타입에
 *     선언된 변수나 메서드만 사용 가능하다.
 *     예외 - 자식 클래스에서 오버라이딩한 메서드가 존재한다면
 *           자식 클래스의 메서드가 호출됨
 */
package day11;
class Food {
	String name = "음식";
	int cal;
	public void desc() {
		System.out.println("상세 설명...");
	}
}
class Rice extends Food {
	String name = "라이스";
	public void desc() {
		System.out.println("밥 상세 설명...");
	}
}
class Cake extends Food {
	String name = "케이크";
	int price;
	int count;
	public void desc() {
		System.out.println("케이크 상세 설명...");
	}
}
public class Test05 {
	public static void call(Food c) {
		c.desc();
	}
	/*
	public static void call(Cake c) {
		c.desc();
	}
	public static void call(Rice c) {
		c.desc();
	}
	*/
	public static void main(String[] args) {
		call(new Cake());
		call(new Rice());
		
		
		
		
		
		
		
		
		
		Food f = new Cake();  // 묵시적 형변환
		f.desc();
		System.out.println(f.name);

		Rice r = (Rice)f;  // 실행시 오류
		
//		Cake c = f;  // 오류
		Cake c = (Cake)f;
	}
}










