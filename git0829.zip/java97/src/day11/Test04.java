package day11;

import java.util.ArrayList;

class Bread /* extends java.lang.Object */ {
	String name;
	int price;
	public Bread() {
		super();
	}
	public Bread(String name, int price) {
		super();
		this.name = name;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Bread [name=" + name + ", price=" + price + "]";
	}
	
}
public class Test04 {
	public static void main(String[] args) {
		String s = new String("a");
		System.out.println(s);

		StringBuffer sb = new StringBuffer();
		sb.append("aaa");
		System.out.println(sb);
		
		int[][] arr = {{1, 2, 3}};
		System.out.println(arr);
		
		ArrayList al = new ArrayList();
		al.add("aa");
		al.add("bb");
		System.out.println(al);
		
		Bread b = new Bread();
		b.name = "바게트";
		b.price = 3500;
		System.out.println(b);
		System.out.println(b.toString());
	}
}







