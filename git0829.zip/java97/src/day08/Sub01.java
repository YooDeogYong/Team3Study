package day08;

import java.util.Arrays;
import java.util.Random;

// 메서드의 선언 클래스1
// 매개변수 선언과 호출 연습
public class Sub01 {
	
	void method01() {
		System.out.println("method01 호출됨...");
	}
	void method02() {
		System.out.println("method02 호출됨...");
	}
	// 누군가 나를 부르려면 int i 형태의 [[값]]을 같이 넘겨야 한다.
	void method03(int i) {
		System.out.printf("method03 %d \n", i);
	}
	// 여러개의 매개변수 선언
	void method04(int i, int j) {
		System.out.printf("method04 %d, %d \n", i, j);
	}
	void method05(char c) {
		System.out.printf("method05 %c \n", c);
	}
	void method06(String str) {
		System.out.printf("method06 %s \n", str);
	}
	void method07(int[] arr) {
		System.out.printf("method07 %s \n", Arrays.toString(arr));
	}
	void method08(Random r) {
		System.out.printf("method08 %s \n", r.toString());
	}
}



