package day08;

import java.util.Random;

// 반환타입과 관련된 선언 
public class Sub02 {
	/*
	 *  반환타입이 void 라면 호출한 곳으로 
	 *  아무값도 넘기지 않겠다.
	 *  return문을 선택적으로 사용한다.
	 *  만약, return문을 사용한다면
	 *  return ; 형태로 써야한다.
	 *  
	 *  반환타입이 void가 아니라면 
	 *  반환타입에 해당하는 값을 반드시
	 *  메서드 종료전에 return 해야 한다.
	 *  값을 넘길때는 
	 *  return 값; 의 형태로 사용
	 */
	void method01() {}
	int method02() {
		return 1;
	}
	
	char method03() {
		return 'a';
	}
	
	String method04() {
		return "abc";
	}
	
	int[] method05() {
		return new int[3];
	}
	
	Random method06() {
		return new Random();
	}
}















