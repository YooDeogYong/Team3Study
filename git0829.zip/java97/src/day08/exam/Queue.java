package day08.exam;

import java.util.Arrays;

public class Queue {

	final int CAPACITY = 10;
	int head = 0, tail = -1, size = 0;
	int[] data = new int[CAPACITY];
	
	public void add(int val) {
		if (size == CAPACITY) {
			System.out.println("비어있는 공간이 없습니다.\n");
			return;
		}

		tail = (tail + 1) % CAPACITY;
		size++;
		data[tail] = val;
	}

	public void remove() {
		if (size == 0) {
			System.out.println("입력된 데이터가 없습니다.\n");
			return;
		}
		int val = data[head];
		data[head] = 0;
		System.out.println("꺼낸값 : " + val);
		head = (head + 1) % CAPACITY;
		size--;
		
	}

	public String show() {
		return Arrays.toString(data);
	}

}
