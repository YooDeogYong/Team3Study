package day08.exam;

import java.util.Scanner;

public class Quiz01 {
	public static void main(String[] args) {
		
		Queue queue = new Queue();
		Scanner sc = new Scanner(System.in);
		
		while (true) {
			System.out.println("------------------");
			System.out.println("1. 입력");
			System.out.println("2. 꺼내기");
			System.out.println("3. 전체데이터 확인");
			System.out.println("0. 종료");
			System.out.println("------------------");
			System.out.print("메뉴 : ");
			int menu = Integer.parseInt(sc.nextLine());
			
			switch (menu) {
			case 1:
				System.out.print("입력 값 : ");
				queue.add(Integer.parseInt(sc.nextLine()));
				break;
			case 2:
				queue.remove();
				break;
			case 3:	
				System.out.println(queue.show());
				break;
			case 0:
				return;
			}
		}
	}
}
