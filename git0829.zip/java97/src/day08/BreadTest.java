package day08;

public class BreadTest {
	public static void main(String[] args) {
		Bread b = new Bread();
		/*
		// private 변수는 직접 접근 불가능
		b.name = "소보루";
		b.price = -100;
		*/
		b.setName("소보루");
		b.setPrice(-100);
		
		/*
		System.out.println("이름 : " + b.name);
		System.out.println("가격 : " + b.price);
		*/
		String name = b.getName();
		System.out.println("이름 : " + name);
		System.out.println("이름 : " + b.getName());
		
		int price = b.getPrice();
		System.out.println("가격 : " + price);
		System.out.println("가격 : " + b.getPrice());
	}
}











