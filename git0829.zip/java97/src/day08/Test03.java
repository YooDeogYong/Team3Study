package day08;

import java.util.Arrays;

public class Test03 {
	public static void main(String[] args) {
		Sub03 sub03 = new Sub03();
		int[] iArr2 = sub03.getArray( 10 );
		
		int[] iArr = sub03.getArray();
		System.out.println(Arrays.toString(iArr));
		
		
		int [] arr1 = {1, 2, 3, 4, 5};
		System.out.println("배열의 합 : " + sub03.sum(arr1));
		
		/*
		int sum = 0;
		for (int val : arr1) {
			sum += val;
		}
		System.out.println("arr1 sum : " + sum);
		*/
		
		int [] arr2 = {11, 22, 33, 44, 55};
		System.out.println("합 : " + sub03.sum(arr2));
		/*
		sum = 0;
		for (int val : arr2) {
			sum += val;
		}
		System.out.println("arr2 sum : " + sum);
		*/
		
		
		
		
		/*
		int sum = sub03.add(100, 200);
		System.out.println("sum : " + sum);
		*/
		
		System.out.println("sum : " + sub03.add(100, 200));
		
		
	}
}




