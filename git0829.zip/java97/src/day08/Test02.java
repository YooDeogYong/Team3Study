package day08;

import java.util.Random;

// 반환타입과 연관된 호출
/*
 * 메서드를 호출하는 쪽에서는
 * 반환타입이 void가 아니라면
 * 반환되는 값을 받을 수 있다.
 */
public class Test02 {
	public static void main(String[] args) {
		Sub02 sub02 = new Sub02();
		sub02.method01();
		sub02.method02();
		int i = sub02.method02();
		System.out.println("i : " + i);
		
		char c = sub02.method03();
		System.out.println(c);
		
		String s = sub02.method04();
		System.out.println(s);
		
		int[] arr = sub02.method05();
		
		Random r = sub02.method06();
	}
}











