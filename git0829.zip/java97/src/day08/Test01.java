package day08;

import java.util.Random;

// Sub01 클래스의 메서드 호출을 연습하는 클래스
public class Test01 {
	public static void main(String[] args) {
		Sub01 sub01 = new Sub01();
		System.out.println("메서드 호출전...");
		
		
		
		
		
		
		
		/*
		sub01.method01();
		sub01.method02();
		sub01.method03(100);
		sub01.method04(100, 200);
		sub01.method05('a');
		sub01.method06("abc");
//		sub01.method07({1, 2, 3});
		// int[] arr = new int[] {1, 2, 3};
		sub01.method07(new int[] {1, 2, 3});
		// int[] arr = new int[3];
		sub01.method07(new int[3]);
		sub01.method08(new Random());
		*/
		System.out.println("메서드 호출후...");
	}
}








