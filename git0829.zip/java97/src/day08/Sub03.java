package day08;

import java.util.Random;

public class Sub03 {
	
	/*
	 *   1 - 45 사이의 랜덤한 숫자 5개를 생성해서 
	 *   생성된 수를 배열에 입력하고 배열을 반환한다.
	 *   메서드 이름 : getArray
	 */
	public int[] getArray() {
		Random r = new Random();
		int[] arr = new int[5];
		for (int i = 0; i < 5; i++) {
			arr[i] = r.nextInt(45) + 1;
		}
		return arr;
	} 
	
	/*
	 *   1 - 45 사이의 숫자를 사용자가 지정한 수만큼 생성해서 
	 *   생성된 수를 배열에 입력하고 배열을 반환한다.
	 *   메서드 이름 : getArray
	 */
	public int[] getArray(int count) {
		Random r = new Random();
		int[] arr = new int[count];
		for (int i = 0; i < count; i++) {
			arr[i] = r.nextInt(45) + 1;
		}
		return arr;
	} 	
	
	
	/**
	 *  문서화 주석문
	 *  클래스, 메서드, 변수에 대한 설명을 할 경우 사용
	 *  두개의 정수를 받아서 두수의 합을 반환하는 add 메서드를 정의  
	 */
	public int add(int i, int j) {
		return i + j;
	}
	
	public int sum(int[] arr) {
		int sum = 0;
		for (int val : arr) {
			sum += val;
		}
		System.out.println("arr sum : " + sum);
		return sum;
	}
}














