package day08;

public class Bread {
	// 내가 선언된 클래스에서만 접근 가능
	private String name;
	private int price;
	
	// alt + shift + s
	// r : 세터, 게터 생성 팝업
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	/*
	// GETTER : 멤버변수에 대한 값을 넘기는 역활
	// public 멤버변수의타입 get변수명() {
	//    return 멤버변수명;
	// }
	public String getName() {
		return name;
	}
	
	public int getPrice() {
		return price;
	}
	
	
	// SETTER : 멤버변수에 대한 값을 설정하는 역활
	// 메서드를 호출하는 곳에서 넘겨준 값을 받아서
	// 멤버변수에 설정한다.
	// public void set변수명(설정할 변수와 동일하게)
	
	// public : 누구나 접근이 가능함...
	public void setName(String n) {
		name = n;
	}
	
	public void setPrice(int p) {
		if (p < 0) {
			System.out.println("잘못된 금액입니다.");
			return ;
		}
		price = p;
	}
	*/
}







