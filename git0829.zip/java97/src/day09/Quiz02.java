package day09;

public class Quiz02 {
	private static String remove(String data, char ch) {
		/*
		String result = "";
		for (int i = 0; i < data.length(); i++) {
			if (data.charAt(i) == ch) continue;
			
			result += data.charAt(i);
//			System.out.print(data.charAt(i));
		}
		return result;
		*/
		StringBuffer result = new StringBuffer();
		for (int i = 0; i < data.length(); i++) {
			if (data.charAt(i) == ch) continue;
			
			result.append(data.charAt(i));
//			System.out.print(data.charAt(i));
		}
		return result.toString();
	}
	
	public static void main(String[] args) {
		String result = remove("hello java", 'a');
		// hello jv
		System.out.println(result);
	}
}



