package day09;

public class Quiz03 {
	private static boolean startsWith(String data, String cmp) {
		int len = cmp.length();
		if (len > data.length()) return false;
		
		for (int i = 0; i < len; i++) {
			if (cmp.charAt(i) != data.charAt(i)) return false;
		}
		
		return true;
	}
	
	private static boolean endsWith(String data, String cmp) {
		int len = cmp.length();
		int len2 = data.length();
		if (len > data.length()) return false;
		
		for (int i = len - 1, j = len2 - 1; i >= 0; i--, j--) {
			if (cmp.charAt(i) != data.charAt(j)) return false;
		}
		
		return true;
	}
	
	public static void main(String[] args) {
		boolean result = startsWith("hello java", "hel");
		// true 가 출력됨
		System.out.println(result);
		
		result = endsWith("hello java", "ava");
		
		/*
		 *   data.charAt(9) != cmp.charAt(2)
		 *   data.charAt(8) != cmp.charAt(1)
		 *   data.charAt(7) != cmp.charAt(0)
		 */
		
		// true 가 출력됨
		System.out.println(result);
	}
}










