/**
 * String 에서 제공되는 주요 메서드 익히기
 */
package day09;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

/*
import java.lang.String;
*/

public class Test03 {
	private static void call(String msg) {}
	public static void main(String[] args) {
		String s = "hello java";
		
		String val = String.valueOf(true);
		System.out.println(val);
		
		val = String.valueOf(100);
		System.out.println(val);
		
		/*
		String name = "홍길동";
		int age = 33;
		String msg = "조선시대 대표적인 의적입니다.";
		
		String info = "이름 : " + name + ", 나이 : " + age + 
		              ", 정보 : " + msg + "\n";
		System.out.print(info);
		call(info);
		
		info = String.format(
				"이름 : %s, 나이 : %d, 정보 : %s\n",
				name, age, msg);
		System.out.print(info);
		call(info);
		*/
		
		/*
		s = "     ab c de     ";
		System.out.println("|" + s + "|");
		// 문자열의 앞, 뒤 공백을 제거
		s = s.trim();
		System.out.println("|" + s + "|");
		
		s = s.replace(" ", "");
		System.out.println("|" + s + "|");
		*/
		
		/*
		s = "홍길동:33:서울특별시:hong@a.com";
		String[] arr = s.split(":");
		System.out.println(Arrays.toString(arr));
		*/
		
		/*
		// 문자열 추출
		String result = s.substring(2);
		System.out.println(result);
		
		result = s.substring(2, 8);
		System.out.println(result);
		*/
		
		/*
		// 문자열 내용을 변환
		String result = s.replace("ello", "i");
		System.out.println(result);
		
		result = s.replaceAll("ello", "i");
		System.out.println(result);
		
		// 정규표현식(Regular Expression)
		s = "1a2b3c4d5e";
		// 숫자를 *로 표시해서 보여주기
		for (int i = 0; i < 10; i++) {
			s = s.replace(i + "", "*");
		}
		System.out.println(s);
		
		s = "가1a2b3c다4d5e나";
		s = s.replaceAll("[0-9A-Za-z]", "*");
		System.out.println(s);
		*/
		
		/*
		s = "Hello Java";
		String result = s.toLowerCase();
		System.out.println(result);
		
		result = s.toUpperCase();
		System.out.println(result);
		*/
		
		
		/*
		// 문자열의 내용을 배열로 변환
		char[] arr = s.toCharArray();
		System.out.println(Arrays.toString(arr));
		
		// 문자열의 내용을 바이트 배열로 변환
		// 네트워크 프로그램에서 사용..
		byte[] bArr = s.getBytes();
		System.out.println(Arrays.toString(bArr));
		
		try {
			bArr = s.getBytes("utf-8");
			System.out.println(Arrays.toString(bArr));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		*/
		
		/*
		// 문자열안에 특정 문자열이 있는지 확인
		boolean result = s.contains("llo");
		System.out.println(result);
		*/
		
		
		
		/*
		// 특정 문자열의 위치 찾기
		int index = s.indexOf("a");
		System.out.println(index);
		
		// 찾지 못했을 경우에는 -1
		index = s.indexOf("lla");
		System.out.println(index);
		
		// a문자열을 8번째 인덱스 위치부터 찾아라..
		index = s.indexOf("a", 8);
		System.out.println(index);
		
		index = s.lastIndexOf("a");
		System.out.println(index);
		
		index = s.lastIndexOf("a", 8);
		System.out.println(index);
		*/
		
		
		/*
		if (s.equals("Hello Java")) {
			
		}
		
		switch (s) {
		case "Hello Java":
			
		}
		*/
		
		/*
		// 대소문자 비교
		boolean result = s.equals("Hello Java"); 
		System.out.println(result);  // false
		
		// 대소문자 무시하고 내용 비교
		result = s.equalsIgnoreCase("Hello Java"); 
		System.out.println(result);  // true
		*/
		
		/*
		boolean result = s.startsWith("hel");
		System.out.println(result);
		
		result = s.endsWith("ava");
		System.out.println(result);
		*/
		
		/*
		// char	charAt(int index)
		char ch = s.charAt(1);
		System.out.println("ch : " + ch);
		System.out.println("ch : " + s.charAt(4));
		
		// int	length()
		int len = s.length();
		System.out.println("길이 : " + len);
		System.out.println("길이 : " + s.length());
		*/
	}
}


















