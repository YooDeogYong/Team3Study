package day09;

public class Test02 {
	public static void main(String[] args) {
		System.out.println("시간측정...");
		String s1 = "hello";
		StringBuffer s2 = new StringBuffer("hello");
		StringBuilder s3 = new StringBuilder("hello");
		
		// 1970년 1월 1일 0시 0분 0초부터 현재 시간까지의 시간을
		// 1000분의 1초로 변환해서 반환
		long s = System.currentTimeMillis();
		for (int i = 0; i < 100000; i++) {
			s1 += i;
		}
		double time = (System.currentTimeMillis() - s) / 1000d;
		System.out.println("String time : " + time + "초");
		
		s = System.currentTimeMillis();
		for (int i = 0; i < 100000; i++) {
			s2.append(i);
		}
		time = (System.currentTimeMillis() - s) / 1000d;
		System.out.println("StringBuffer time : " + time + "초");
		
	}
}






