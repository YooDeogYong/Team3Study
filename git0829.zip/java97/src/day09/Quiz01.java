package day09;

public class Quiz01 {
	/**
	 * 매개변수에 입력된 data 문자열의 내용을 
	 * 문자하나씩 줄넘김 하면서 출력
	 * @param data
	 */
	public static void nlPrint(String data) {
		nlPrint(data, false);
	}
	
	private static void nlPrint(String data, boolean isReverse) {
		if (isReverse) {
			for (int i = data.length() - 1; i >= 0; i--) {
				System.out.println(data.charAt(i));
			}
			return;
		}
		for (int i = 0; i < data.length(); i++) {
			System.out.println(data.charAt(i));
		}
	}
	
	public static void main(String[] args) {
		String str = "hello java";
		/*
		 * h
		 * e
		 * l
		 * l
		 * o
		 * 
		 * j
		 * a
		 * v
		 * a
		 */
		nlPrint(str);
		
		// true 일 경우 출력을 꺼꾸로
		// a
		// v
		// a
		// j
		// ...
		// ...
		// h
		nlPrint(str, true);
	}
}










