package day09;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Test04 {
	private static void getActors(int age) {
		try {
			
			Scanner sc = new Scanner(
					new File("data/day09/test04.txt"));
			/*
			 *   이름 : 정우성, 나이 : 24  
			 */
			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				String[] arr = line.split(":");
				if (Integer.parseInt(arr[1]) <= age) continue;
				
				System.out.printf(
						"이름 : %s, 나이 : %s\n", 
						arr[0], arr[1]);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}		
	}
	private static void getActors(String name) {
		try {
			
			Scanner sc = new Scanner(
					new File("data/day09/test04.txt"));
			/*
			 *   이름 : 정우성, 나이 : 24  
			 */
			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				String[] arr = line.split(":");
				
				if (arr[0].startsWith(name) == false) continue;
				
				System.out.printf(
						"이름 : %s, 나이 : %s\n", 
						arr[0], arr[1]);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}		
	}
	
	public static void main(String[] args) {
		getActors(30);
		getActors("정");
	}
}









