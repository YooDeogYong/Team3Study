package day09;

public class Test01 {
	public static void main(String[] args) {
		// String은 상수형 클래스가 된다.
		// String의 내용을 변경하면 새롭게 메모리를 할당
		String s1 = "hello";
		String s2 = "hello";
		String s3 = new String("hello");
		
		if (s1 == s2) {
			System.out.println("s1 == s2");
		}
		if (s2 == s3) {
			System.out.println("s2 == s3");
		}
	}
}









