package day14;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Test02 {
	public static void main(String[] args) {
//		List<String> list = new ArrayList<>();
		List<String> list = new LinkedList<>();
		// 데이터 추가
		list.add("one");
		list.add("two");
		list.add("three");
		// 크기 확인
		System.out.println("크기 : " + list.size());
		
		// 데이터 삭제
		list.remove(0); // one 삭제
		System.out.println("삭제 후 크기 : " + list.size());
		System.out.println("데이터 확인 : " + list);
		// 객체를 이용한 삭제
		list.remove("two");
		System.out.println("삭제 후 데이터 확인 : " + list);
		
		// 데이터의 인덱스 위치 검색
		int index = list.indexOf("three");
		System.out.println("three 의 위치 : " + index);
		
		index = list.indexOf("four");
		System.out.println("four 의 위치 : " + index);
		
		// 데이터가 비어있는지 확인
		boolean empty = list.isEmpty();
		System.out.println("비어있나 : " + empty);
		
		// 모든 데이터를 삭제
		list.clear();
		
		empty = list.isEmpty();
		System.out.println("전체 데이터 삭제 후 비어있나 : " + empty);
		
		list.add("one");
		
		List<String> sub = new ArrayList<>();
		sub.add("four");
		sub.add("five");
		sub.add("six");
		
		// sub 리스트의 데이터를 list 리스트에 모두 입력
		list.addAll(sub);
		
		// 데이터 확인
		System.out.println(list);
		System.out.println(sub);
	}
}











