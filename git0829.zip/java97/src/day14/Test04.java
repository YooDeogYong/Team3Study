package day14;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Test04 {
	public static void main(String[] args) {
		Set<String> set = new HashSet<>();
		
		set.add("one");
		set.add("two");
		set.add("three");
		// 데이터의 중복을 허용하지 않는다. 입력(X)
		set.add("two");
		
		System.out.println("데이터 확인 : " + set);
		System.out.println("데이터 크기 : " + set.size());
		
		// 데이터 삭제 : index 활용은 불가능
		set.remove("one");
		System.out.println("삭제 후 데이터 확인 : " + set);
		
		// set의 데이터를 출력 : get(index) 제공안됨..
		for (String str : set) {
			System.out.println(str);
		}
		
		Iterator<String> ite = set.iterator();
		while (ite.hasNext()) {
			String str = ite.next();
			System.out.println(str);
		}
	}
}












