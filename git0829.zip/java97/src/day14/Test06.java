package day14;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Test06 {
	public static void main(String[] args) {
		// 맵이 가지고 있는 모든 데이터를 출력하자.
		Map<String, String> map = new HashMap<>();
		map.put("id", "hong");
		map.put("name", "홍길동");
		map.put("email", "a@a.com");
		
		Set<String> keys = map.keySet();
		for (String key : keys) {
			System.out.println("key : " + key);
			System.out.println("value : " + map.get(key));
		}
		
	}
}



















