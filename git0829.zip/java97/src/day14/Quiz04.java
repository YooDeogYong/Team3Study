package day14;

public class Quiz04 {
	public static void main(String[] args) {
		/*
		성적 발표
		========================
		1. 이름 : 배영만, 총점 : 264
		2. 이름 : 배수민, 총점 : 257
		3. 이름 : 배근영, 총점 : 227
		========================
		 */
		try {
			new Quiz04DAO().load();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}





