package day14;

public class Box01 {
	private String data;

	public void setData(String data) {
		this.data = data;
	}

	public String getData() {
		return data;
	}
	
}
