package day14;

import java.util.HashMap;
import java.util.Map;

class Member {
	private String id;
	private String name;
	private String password;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
public class Quiz02 {
	public static void main(String[] args) {
		// 회원 정보를 저장
		// hong, 홍길동, 1234
		Member m1 = new Member();
		m1.setId("hong");
		m1.setName("홍길동");
		m1.setPassword("1234");
		// Map 으로 위의 데이터를 표현
		Map<String, String> map = new HashMap<>();
		map.put("id", "hong");
		map.put("name", "홍길동");
		map.put("password", "1234");
	}
}











