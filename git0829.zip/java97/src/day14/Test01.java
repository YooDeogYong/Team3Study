package day14;

public class Test01 {
	public static void main(String[] args) {
		/*
		Box01 box01 = new Box01();
		box01.setData("귤");
//		box01.setData(100);  // 원하는 데이터만 담는다.
		
		Box02 box02 = new Box02();
		box02.setData("귤");
		// 다양한 타입은 받을 수 있지만 항상 꺼낼때 형변환을 사용해야 한다.
		String data = (String)box02.getData();
		// 원하는 타입 이외의 데이터가 들어오는걸 막을 수 없다.
		box02.setData(100);   // Object data = new Integer(100);
		
		Box02 box021 = new Box02();
		box021.setData(100);
		
		// 1.7 버전 부터 생성 부분에 <> 형태를 지원
		Box03<String> box03 = new Box03<>();
		box03.setData("귤");
//		box03.setData(100);
		
		Box03<Integer> box031 = new Box03<>();
		box031.setData(1000);

		Box03<Object> box032 = new Box03<>();
		box032.setData(1000);
		box032.setData("aaa");
		 */
		
		Box04<Integer, String> box041 = 
				new Box04<>(1, "영등포");
		System.out.println(box041.getKey());
		System.out.println(box041.getValue());

		Box04<Integer, String> box042 = 
				new Box04<>(2, "강남구");
	}
}














