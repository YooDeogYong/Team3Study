package day14;

public class Quiz03VO {
	private String name;
	private int age;
	private String genre;
	private String gender;  // 1 : 남성, 2 : 여성
	
	public Quiz03VO() {}
	
	public Quiz03VO(String name, int age, String genre, String gender) {
		this.name = name;
		this.age = age;
		this.genre = genre;
		this.gender = gender;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Quiz03VO [name=" + name + ", age=" + age + ", genre=" + genre + ", gender=" + gender + "]";
	}
}











