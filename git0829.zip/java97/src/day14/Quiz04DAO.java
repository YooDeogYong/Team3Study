package day14;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Quiz04DAO {
	List<Quiz04VO> list = new ArrayList<>();
	public void load() throws FileNotFoundException {
		Scanner sc = new Scanner(
				new File("data/day14/quiz04.txt")
		);
		while (sc.hasNextLine()) {
			String[] info = sc.nextLine().split(":");
			list.add(new Quiz04VO(
					info[0], 
					Integer.parseInt(info[1]), 
					Integer.parseInt(info[2]), 
					Integer.parseInt(info[3]) 
			));
		}
		Collections.sort(list);
		
		
		System.out.println("성적 발표");
		System.out.println("========================");
		for (int i = 0; i < 3; i++) {
			Quiz04VO data = list.get(i);
			System.out.printf(
				"%d. 이름 : %s, 총점 : %d\n",
				i + 1, data.getName(), data.getSum()
			);	
		}
		System.out.println("========================");
	}
}











