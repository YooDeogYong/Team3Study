package day14;

import java.util.Arrays;

public class Test07 {
	public static void main(String[] args) {
		int[] arr = {3, 9, 5};
		
		// 오름차순(ascending) : 값이 커지는 것..   3, 5, 9 
		// 내림차순(descending) : 값이 작아지는 것..   9, 5, 3
		
		// 정렬 알고리즘
		// 출력 :  3, 5, 9
		/*
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] < arr[j]) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		*/
		for (int i = 0; i < arr.length - 1; i++) {
			int index = i;
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[index] < arr[j]) {
					index = j;
				}
			}
			int temp = arr[i];
			arr[i] = arr[index];
			arr[index] = temp;
		}
		System.out.println(Arrays.toString(arr));
		
	}
}










