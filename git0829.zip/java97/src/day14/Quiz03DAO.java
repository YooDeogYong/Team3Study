package day14;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Quiz03DAO {
	List<Quiz03VO> list = new ArrayList<>();
	
	public void load() throws Exception {
		Scanner sc = new Scanner(new File("data/day14/quiz03.txt"));
		while (sc.hasNextLine()) {
			String line = sc.nextLine();
			String[] info = line.split(":");
			Quiz03VO vo = new Quiz03VO(
					info[0], 
					Integer.parseInt(info[1]),
					info[2],
					info[3]		
			); 
			list.add(vo);
		}
		System.out.println("데이터 로딩 완료...");
		System.out.println(list);
	}
}









