package day14;

public class Data implements Comparable<Data> {
	private int num;
	public Data(int num) {
		this.num = num;
	}
	public int getNum() {
		return num;
	}
	public String toString() {
		return String.valueOf(num);
	}
	
	/*
	 *   리턴되는 결과값에 따라서 위치가 변경된다.
	 *   0 이 리턴되면 변화가 없다.
	 *   음수값이 리턴되면  비교대상보다 앞으로 이동
	 *   양수값이 리턴되면  비교대상보다 뒤로 이동
	 */
	@Override
	public int compareTo(Data o) {
		return this.num < o.getNum() ? -1 : 1;
	}
}












