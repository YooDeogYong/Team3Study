package day14;

public class Quiz03 {
	public static void main(String[] args) {
		try {
			new Quiz03DAO().load();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
