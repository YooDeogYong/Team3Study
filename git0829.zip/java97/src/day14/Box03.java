/*
 *    Generic : 1.5 부터 지원
 *    - 클래스이름<파라미터>
 */
package day14;

public class Box03<T> {
	private T data;
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
}












