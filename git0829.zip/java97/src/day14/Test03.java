package day14;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test03 {
	public static void main(String[] args) {
		// 리스트의 데이터 추출하기
		List<String> list = new ArrayList<>();
		list.add("a");
		list.add("b");
		list.add("c");
		
		/*
		System.out.println(list.get(0));
		System.out.println(list.get(1));
		System.out.println(list.get(2));
		*/
		/*
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
		*/
		/*
		for (String data : list) {
			System.out.println(data);
		}
		*/
		// 순환자를 이용한 반복 : Iterator
		Iterator<String> ite = list.iterator();
		while (ite.hasNext()) {
			String data = ite.next();
			System.out.println(data);
		}
	}
}



















