package day14;

import java.util.HashMap;
import java.util.Map;

public class Test05 {
	public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();
		// 데이터 입력
		map.put("id", "hong");
		map.put("name", "홍길동");
		
		// 데이터 꺼내기
		String id = map.get("id");
		System.out.println("id : " + id);
		
		// key에 해당하는 값이 없을 경우 null 을 반환한다.
		String email = map.get("email");
		System.out.println("email : " + email);
		
		// 기본에 존재하는 key를 입력했을 경우 ??
		// 새로운 값으로 변경된다.
		/*
		String prevId = map.get("id");
		System.out.println("변경되기 전 id : " + prevId);
		*/
		String prevId = map.put("id", "kang");
		System.out.println("변경되기 전 id : " + prevId);
		id = map.get("id");
		System.out.println("id : " + id);
		
		String prevEmail = map.put("email", "a@a.com");
		System.out.println("이전 email : " + prevEmail);
	}
}




















