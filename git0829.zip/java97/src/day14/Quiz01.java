package day14;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class Quiz01 {
	public static void main(String[] args) {
		// 중복되지 않은 숫자 6개를 생성(1 ~ 45) 사이
		// HashSet에 데이터를 담는다.
		// 담겨진 데이터를 출력
		Set<Integer> set = new HashSet<>();
		Random r = new Random();
		while (set.size() < 6) {
			set.add(r.nextInt(45) + 1);
		}
		System.out.println(set);
	}
}











