package day13;

import java.util.Calendar;

public class Test03 {
	public static void main(String[] args) {
		// getInstance : 시스템과 연관된 Calendar 클래스의 자식 클래스 반환
		Calendar c = Calendar.getInstance();
		System.out.println(c);
		// 추출 
		System.out.println(c.get(1));  // year
		System.out.println(c.get(2));  // month
		// www.naver.com,    192,111.233.123
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH) + 1; // 0 ~ 11
		int date = c.get(Calendar.DATE);
//		int date = c.get(Calendar.DAY_OF_MONTH);
		
		// 시, 분, 초
		int hour = c.get(Calendar.HOUR);
        int minute = c.get(Calendar.MINUTE);
		int second = c.get(Calendar.SECOND);
		
		System.out.printf(
				"%d-%02d-%02d %d:%d:%d\n",
				year,
				month,
				date,
				hour,
				minute,
				second);
	
		int day = c.get(Calendar.DAY_OF_WEEK);  // 1(일) ~ 7(토)
		// day 가 4이므로  "요일 : 수" 라고 출력됨..
		// if, switch
		String[] arr = {"일", "월", "화", "수", "목", "금", "토"};
		
		System.out.println("요일 : " + arr[day - 1]);
		
		// c 객체의 현재 날짜 정보가 2017-02-11 이라면
		// getActualMaximum : 28
		// getMaximum : 31
		int last = c.getActualMaximum(Calendar.DAY_OF_MONTH);
		System.out.println("ActualMaximum : " + last);
		last = c.getMaximum(Calendar.DAY_OF_MONTH);
		System.out.println("Maximum : " + last);
	}
}



















