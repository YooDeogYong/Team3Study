package day13;

import java.util.Date;

public class Test02 {
	public static void main(String[] args) {
		Date d = new Date();
		long time = d.getTime();
		System.out.println("현재시간 long : " + time);
		
		// 시간 정보 변경
		d.setTime(1000 * 60);
		System.out.println("변경된 시간 : " + d);
	}
}









