package day13;

import java.util.Calendar;

public class Test04 {
	public static void main(String[] args) {
		// Calendar 객체를 이용한 날짜 변경하기
		Calendar c = Calendar.getInstance();
		// 2015년 2월 10일로 날짜 변경
//		c.set(2015, 1, 10);
		// 현재날짜에서 년과 월을 그대로 두고 일 부분만 1일로 변경
//		c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), 1);
		c.set(Calendar.DATE, 1);
		
		/*
		int month = c.get(Calendar.MONTH) -1;
		c.set(Calendar.MONTH, month);
		*/
		
		// 상대적인 날짜 계산이 필요 할 경우..
		// 월 부분을 이전 달로
		c.add(Calendar.MONTH, -1);
		// 월 부분을 다음 달로
		c.add(Calendar.MONTH, 1);
		// 일 부분을 7일 뒤로
		c.add(Calendar.DATE, 7);
		
		System.out.println(c.get(Calendar.DATE));
	}
}










