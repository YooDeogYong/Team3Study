package day13;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Test05 {
	public static void main(String[] args) {
		// 2017-08-09 11:23:11
		// 2017년 08월 09일 11시 23분 11초
		// 날짜 객체 얻기, 날짜 정보를 얻기위해서 메서드 호출..
		// SimpleDateFormat
		// 날짜 -> 문자열 형태로 변환 : format
		// 문자열 -> 날짜 형태로 변환 : parse
		// 현재날짜 객체 -> 2017/08
		/*
		 *   날짜 패턴 문자
		 *   y -> 년도
		 *   M -> 월
		 *   d -> 일
		 *   H -> 시(24시간 단위)
		 *   h -> 시(12시간 단위)
		 *   m -> 분
		 *   s -> 초
		 */
		SimpleDateFormat sdf = 
				new SimpleDateFormat("yyyy-MM-dd");
		String result = sdf.format(new Date());  // 날짜 -> 문자열
		System.out.println(result);
		try {
			Date d = sdf.parse("2017-12-25");  // 문자열 -> 날짜
			System.out.println("생성된 날짜 정보 : " + d);
		} catch (ParseException e) {
			System.out.println("날짜 객체 생성 중 오류 발생");
			e.printStackTrace();
		}
	}
}








