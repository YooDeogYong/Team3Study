package day13;

import java.io.File;
import java.util.Date;

public class Test01 {
	public static void main(String[] args) {
		// 현재 시간 정보를 추출
		Date d1 = new Date();
		System.out.println(d1);
		
		// 1000 -> 1초
		// 1970년 기준으로 long의 값을 적용
		Date d2 = new Date(1000 * 60 * 60);
		System.out.println(d2);
		
		File f = new File("data/day09/test04.txt");
		long time = f.lastModified();
		System.out.println(time);
		
		Date d3 = new Date(time);
		System.out.println(d3);
		
		// deprecated -> 사용하면 안됨..
		Date d4 = new Date(107, 11, 11);
	}
}











