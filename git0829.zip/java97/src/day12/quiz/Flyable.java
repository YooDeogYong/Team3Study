package day12.quiz;

public interface Flyable {

	void fly();

}
