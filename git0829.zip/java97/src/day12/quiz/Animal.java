package day12.quiz;

public abstract class Animal {
	public abstract void cry();
}
