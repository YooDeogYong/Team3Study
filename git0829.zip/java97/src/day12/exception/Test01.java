package day12.exception;

public class Test01 {                      // 간접 처리   
	public static void main(String[] args) throws Exception {
		String msg = null;
		// 실행 시점 예외(unchecked exception)
		System.out.println(msg.length());
		
		/*
		File f = new File("a.txt");
		// 컴파일 시점 예외(checked exception)
		// 파일이 존재하지 않을 경우 문제 됩니다.(FileNotFoundException)
		Scanner sc = new Scanner(f);
		*/  
	}
}








