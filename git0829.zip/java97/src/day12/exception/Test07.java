package day12.exception;

import java.io.FileReader;

public class Test07 {
	public static void main(String[] args) {
		/*
		 *   finally : 예외 발생 여부와 상관없이 실행(무조건)
		 *   - 외부자원과 연결되어 있는 경우 외부자원을 닫을 경우 사용
		 *   
		 *   try ~ catch
		 *   try ~ finally
		 *   try ~ catch ~ finally
		 */
		try {
			System.out.println(1);
			FileReader fr = new FileReader("a.txt");
			System.out.println(2);
		} catch (Exception e) {
			System.out.println(3);
//			return;
			System.exit(0);
		} finally {
			System.out.println(4);
		}
		System.out.println(5);
	}
}











