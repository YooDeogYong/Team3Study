package day12.exception;

public class Test06 {
	public static void main(String[] args) { 
		try {
			String s = null;
			// NullPointerException
			System.out.println(s.length());
			// ArithmeticException
			System.out.println(1 / 0);
		// 1.7 버전 부터 가능한 방법
		} catch (NullPointerException | ArithmeticException e) {
			e.printStackTrace();
		} catch (Exception e) {
		
		}
	}
}












