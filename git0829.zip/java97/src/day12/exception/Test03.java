package day12.exception;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Test03 {
	public static void main(String[] args) {
		File f = new File("a.txt");
		try {
			Scanner sc = new Scanner(f);
		} catch (FileNotFoundException e) {
			System.out.println("예외 발생");
			System.out.println("예외 메세지 : " + e.getMessage());
			System.out.println("------------------------------");
			// 상세 예외 정보 출력
			e.printStackTrace();
			System.out.println("------------------------------");
		}
	}
}










