package day12.exception;
/*
 *  Exception (String msg) 
 * 
 * 
 */
public class JuminNumberException extends Exception {
	public JuminNumberException() {
		super("주민번호는 13자리를 입력하세요");
	}
	public JuminNumberException(String msg) {
		super("주민번호(" + msg + ")는 13자리를 입력하세요");
	}
}














