package day12.exception;

import java.util.Scanner;

public class JuminService {
	public boolean service() throws JuminNumberException {
		Scanner sc = new Scanner(System.in);
		System.out.print("주민번호 입력 : ");
		String juminNo = sc.nextLine();
		// juminNo 에서 "-"은 제거하고 13자리인지 확인
		juminNo = juminNo.replace("-", "");
		if (juminNo.length() != 13) {
			// 잘못된 주민번호 이므로 예외를 발생...
//			throw new JuminNumberException();
			throw new JuminNumberException(juminNo);
		}
		return true;
	}
}










