package day12.exception;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Test02 {
	public static void main(String[] args) {
		/*
		 *  예외 직접 처리 방식
		 *  
		 *  try : 예외가 발생할 만한 부분을 묶는다.
		 */
		File f = new File("a.txt");
		try {
				
			Scanner sc = new Scanner(f);
			// FileNotFoundException e = new FileNotFoundException(...);
			// IOException e = new FileNotFoundException(...);
			// Exception e = new FileNotFoundException(...);
			// Throwabel e = new FileNotFoundException(...);
//		} catch (Object e) {
//			System.out.println("예외가 발생했음...");
		} catch (Throwable e) {
			System.out.println("예외가 발생했음...");
//		} catch (Exception e) {
//			System.out.println("예외가 발생했음...");
//		} catch (IOException e) {
//			System.out.println("예외가 발생했음...");
//		} catch (FileNotFoundException e) {
//			System.out.println("예외가 발생했음...");
		}
	}
}













