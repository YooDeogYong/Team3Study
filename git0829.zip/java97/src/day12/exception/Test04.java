package day12.exception;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Test04 {
	public static void main(String[] args) {
		try {
			FileReader fr = new FileReader("a.txt");
			fr.read();
		} catch (FileNotFoundException e) {
			System.out.println("파일 찾지 못했음..");
		} catch (IOException e) {
			System.out.println("읽다가 오류 났음");
		}
		
		try {
			FileReader fr = new FileReader("a.txt");
			fr.read();
		} catch (IOException e) {
		}

		try {
			FileReader fr = new FileReader("a.txt");
			fr.read();
		} catch (Exception e) {
		}
	}
}






