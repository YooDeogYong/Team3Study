package day12.exception;

public class Test05 {
	public static void main(String[] args) {
		
		/*
		// 1번 출력 후 예외 발생 후 비정상 종료
		
		System.out.println(1);
		String s = null;
		// 예외발생... : 실행시
		System.out.println(s.length());
		
		System.out.println("end");
		*/
		
		/*
		// 1 - 3 - end
		// 예외 발생 시 처리할 수 있는 catch 블럭으로 이동
		// catch 블럭 수행 후 나머지 코드 수행...
		System.out.println(1);
		try {
			String s = null;
			// 예외발생... : 실행시
			System.out.println(s.length());
			System.out.println(2);
		} catch (Exception e) {
			System.out.println(3);
		}
		System.out.println("end");
		*/
		// 1 - 3 - 2 - end
		System.out.println(1);
		try {
			String s = "abc";
			System.out.println(s.length());
			System.out.println(2);
		} catch (Exception e) {
			System.out.println(3);
		}
		System.out.println("end");
	}
}












