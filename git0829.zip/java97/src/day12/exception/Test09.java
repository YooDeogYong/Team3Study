/*
 *   사용자가 정의하는 예외 클래스 
 */
package day12.exception;

public class Test09 {
	public static void main(String[] args) {
		JuminService js = new JuminService();
		try {
			js.service();
		} catch (JuminNumberException e) {
			e.printStackTrace();
		}
	}
}






