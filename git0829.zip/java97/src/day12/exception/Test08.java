package day12.exception;

import java.io.FileNotFoundException;
import java.io.FileReader;

class Alba {
	public void work() throws Exception {
		try {
			FileReader fr = new FileReader("a.txt");
		} catch (Exception e) {
			System.out.println("알바 예외 처리 진행...");
			// 예외를 사장한테.. 던져주어야 한다.
			// 개발자가 코드상에 직접 예외를 발생시키자..
			throw e;
		}
	}
}
public class Test08 {
	public static void main(String[] args) {
		Alba alba = new Alba();
		try {
			alba.work();
		} catch (Exception e) {
			System.out.println("사장 예외 처리 진행...");
//			e.printStackTrace();
		}
	}
}








