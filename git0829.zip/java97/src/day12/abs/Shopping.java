package day12.abs;

public interface Shopping {
	public void buy();
}
