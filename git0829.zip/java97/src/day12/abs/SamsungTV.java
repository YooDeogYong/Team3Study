package day12.abs;

public class SamsungTV implements TV, Runnable {
	@Override
	public void powerOn() {
		System.out.println("Samsung powerOn");
	}
	@Override
	public void powerOff() {
		System.out.println("Samsung powerOff");
	}
	@Override
	public void soundUp() {
		System.out.println("Samsung soundUp");
	}
	@Override
	public void soundDown() {
		System.out.println("Samsung soundDown");
	}
	@Override
	public void mute() {
		System.out.println("Samsung mute");
	}
	@Override
	public void channelUp() {
		System.out.println("Samsung channelUp");
	}
	@Override
	public void channelDown() {
		System.out.println("Samsung channelDown");
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
}
















