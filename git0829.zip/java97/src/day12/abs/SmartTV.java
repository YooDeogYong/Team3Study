package day12.abs;

public interface SmartTV extends TV, Shopping, Touch {

}
