package day12.abs;

public interface TV {
	// 1.8 버전... default, static 메서드 선언이 가능
	public default void test() {}
	public static void test2() {}
	
	int MAX_SOUND = 100;  // public static final 자동 추가
	void powerOn();  // public abstract 자동 추가 
	void powerOff();  // public abstract 자동 추가 
	void soundUp();  // public abstract 자동 추가 
	void soundDown();  // public abstract 자동 추가 
	void mute();  // public abstract 자동 추가 
	void channelUp();  // public abstract 자동 추가 
	void channelDown();  // public abstract 자동 추가 
}







