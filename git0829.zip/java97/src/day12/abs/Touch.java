package day12.abs;

public interface Touch {
	public void touch();
}
