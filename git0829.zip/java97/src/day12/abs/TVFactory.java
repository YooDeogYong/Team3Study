package day12.abs;

public class TVFactory {
	public static TV getInstance(String type) {
		switch (type) {
		case "samsung":
			return new SamsungTV();
		case "lg":
			return new LgTV();
		}
		return null;
	}
}
