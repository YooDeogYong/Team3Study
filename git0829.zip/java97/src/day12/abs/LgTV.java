package day12.abs;

public class LgTV implements TV {
	@Override
	public void powerOn() {
		System.out.println("Lg powerOn");
	}
	@Override
	public void powerOff() {
		System.out.println("Lg powerOff");
	}
	@Override
	public void soundUp() {
		System.out.println("Lg soundUp");
	}
	@Override
	public void soundDown() {
		System.out.println("Lg soundDown");
	}
	@Override
	public void mute() {
		System.out.println("Lg mute");
	}
	@Override
	public void channelUp() {
		System.out.println("Lg channelUp");
	}
	@Override
	public void channelDown() {
		System.out.println("Lg channelDown");
	}
}
















