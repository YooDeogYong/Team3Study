package day12.abs;

public class Test02 {
	public static void main(String[] args) {
		System.out.println(TV.MAX_SOUND);  // static 
//		TV.MAX_SOUND = 200;  // final
		
		// 인터페이스는 추상 개념이기 때문에 객체 생성 불가
//		TV tv = new TV();
		TV tv = TVFactory.getInstance("samsung");
		tv.powerOn();
		tv.powerOff();
		
		tv = TVFactory.getInstance("lg");
		tv.powerOn();
		tv.powerOff();
		/*
		TV tv = new SamsungTV();
		tv.powerOn();
		tv.powerOff();
		
		tv = new LgTV();
		tv.powerOn();
		tv.powerOff();
		*/
	}
}











