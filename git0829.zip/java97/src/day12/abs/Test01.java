/*
 *   추상 : abstract, 클래스와 메서드, 구현하지 않은...
 *   
 *   - 자식 클래스를 이용해서 객체를 얻는다.
 *   - 추상메서드 + 구체화된 메서드 선언 가능함.
 */
package day12.abs;
abstract class AbsSuper {  // 추상클래스 - 표시..
	public abstract void call();  // 추상메서드
	// 구체화된 메서드
	public void test() {
		System.out.println("추상클래스의 구현된 메서드");
	}
}

// 추상 클래스를 상속받는 하위 클래스는 반드시 추상 메서드를 오버라이딩 해야 한다.
class AbsSub extends AbsSuper {
	public void call() {
		System.out.println("재정의된 메서드");
	}
}
public class Test01 {
	public static void main(String[] args) {
		// 추상클래스는 객체 생성 불가
//		AbsSuper aSuper = new AbsSuper(); 
		// 추상클래스 타입의 변수는 상속관계를 이용해서 얻는다.(형변환)
		AbsSuper aSuper = new AbsSub();
		aSuper.call();
	}
}
















