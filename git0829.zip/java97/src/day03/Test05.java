package day03;

public class Test05 
{
	public static void main(String[] args) 
	{
		/*
		int num = (5 < 3) ? 5 : 3;	
		System.out.println( num );
		*/

		System.out.println( (5 < 3) ? 5 : 3 );


	}
}










