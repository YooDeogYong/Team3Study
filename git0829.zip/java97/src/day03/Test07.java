package day03;

public class Test07 {
	public static void main(String[] args) {
		int a = 5;
		a++;  // a = a + 1;
		++a;  // a = a + 1;
		System.out.println(a);
		
		a--;  // a = a - 1;
		--a;  // a = a - 1;
		System.out.println(a);
		
		// a = 5
//		int b = ++a;
		int b = a++;
		
		System.out.println(a + "," + b);
		
		a = 5;
//		System.out.println(a++);
//		System.out.println(++a);
		
		System.out.println(++a);   // 6
		System.out.println(a);     // 6
		System.out.println(a++);   // 6
		System.out.println(a--);   // 7
		
		
		
	}
}
















