package day03;

import java.util.Random;

public class Quiz02 {
	public static void main(String[] args) {
		// 랜덤한 숫자 하나를 생성해서(1 - 10)
		// 생성된 숫자가 홀수 인지 짝수 인지 판단하는 프로그램 작성
		// 출력 형식
		// 생성된 3은 홀수입니다.
		// 생성된 7은 짝수입니다.
		/*
		Random r = new Random();
		int num = r.nextInt(10) + 1;
		String result = (num % 2 == 0) ? "짝수" : "홀수";
		System.out.println("생성된 " + num + "은 " + result + "입니다.");
		*/
		int num = new Random().nextInt(10) + 1;
		System.out.printf(
				"생성된 %d은 %s입니다.", 
				num, 
				(num % 2 == 0) ? "짝수" : "홀수"
		);
	}
}












