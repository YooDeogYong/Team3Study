package day03;

public class Test09 {
	public static void main(String[] args) {
		int a = 5;
		int b = 5;
		
		System.out.println( !(a > 5));
		
		System.out.println(a > 5 && b++ == 5);
//		System.out.println(a > 5 & b++ == 5);
		System.out.println("b = " + b);
	}
}









