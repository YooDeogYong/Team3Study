package day03;

import java.util.Scanner;

public class Test11 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("달러를 입력하세요 : ");
		String val = sc.nextLine();
		System.out.println("입력 받은 값 : " + val);
	}
}









