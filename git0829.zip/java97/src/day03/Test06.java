package day03;

public class Test06 {
	public static void main(String[] args) {
		System.out.println("산술연산자");
		
		int a = 5;
		int b = 2;
		
		System.out.println(5 + 2);  // 7
		System.out.println(5 - 2);  // 3
		System.out.println(5 * 2);  // 10
		System.out.println(5 / 2);  // 2
		System.out.println(5 % 2);  // 1
		
		// byte, char, short, int 의 산술연산   -> 결과는 int
		byte b1 = 100;
		byte b2 = 10;
		
//		byte b3 = b1 + b2;  // byte + byte의 연산 결과는 int가 된다.(오류)
		System.out.println('a' + 'b');
		
		//   long + int  ->  long
		//   float + int ->  float
		//   double + int ->  double
		
		System.out.println(5 / 2.0);
		System.out.println(5 / 2d);
		System.out.println((double)(5 / 2));
		
		double result = 5 / 2;
		System.out.println(result);
		
		System.out.println(1 + 'a');
		System.out.println( (char)(1 + 'a') );
		
		System.out.println(1 % 2);  // 1
		System.out.println(2 % 2);  // 0
		System.out.println(3 % 2);  // 1
		System.out.println(4 % 2);  // 0
		System.out.println(5 % 2);  // 1
		
		System.out.println(20 % 10 == 0 ? "10의 배수" : "10의 배수가 아님");
		
		
		
	}
}





















