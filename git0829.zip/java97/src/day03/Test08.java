package day03;

public class Test08 {
	public static void main(String[] args) {
		int a = 5;
		int b = 3;
		
		// b 가 1보다 크고 5보다 작은지 체크
		// 1 < b < 5
		System.out.println(a >  b);  // true
		System.out.println(a >= b);  // true
		System.out.println(a <  b);  // false
		System.out.println(a <= b);  // false
		System.out.println(a == b);  // false
		System.out.println(a != b);  // true
		
		/*
		boolean result = a > b;
		System.out.println(result);
		*/
	}
}







