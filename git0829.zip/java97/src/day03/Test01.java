package day03;

public class  Test01
{
	public static void main(String[] args) 
	{
		// 숫자 상수는 정수는 int, 실수는 double가 기본으로 설정됨...
		// 정수타입 
		// byte b = 128;  // 에러발생, 최대범위가 127 이므로 
		//byte b = 127;
		short s = 100;
		int i = 100;
		// int i2 = 100l;   // long 타입은 int 보다 담을수 있는 숫자의 크기가 크므로 에러발생
		                         // 숫자의 범위가 큰 타입을 작은 타입에 대입하기 위해서는 별도의 작업이 필요함
		// long  데이터타입의 값을 표기하기 위해서 숫자뒤에 l, L을 붙일수 있음
		long l = 100;
        long l2 = 100l;
		long l3 = 100L;

		// 실수
		// float f = 1.1;   // 에러발생,  실수는 별도의 표시가 없으면 double 로 인식함
		                         // 큰타입은 작은 타입에 입력 될 수 없음..
        // 실수를 float로 대입하기 위해서 숫자뒤에 f, F를 붙여서 사용
		float f = 1.1f;
		float f2 = 1.1F;

		double d = 1.1;
		double d2 = 1.1d;
		double d3 = 1.1D;

		// 논리형
		boolean bool = true;
		boolean bool2 = false;

		// 문자, 아스키코드 : 문자에 대한 숫자값....
		char  c = 'a';
		char c2 = 97;
		char c3 = 65;
		char c4 = '\u0061';
		char c5 = '\uac00';

		System.out.println("c = " + c);
		System.out.println("c2 = " + c2);
		System.out.println("c3 = " + c3);
		System.out.println("c4 = " + c4);
		System.out.println("c5 = " + c5);

	}
}










