package day03;

public class Test10 {
	public static void main(String[] args) {
		int a = 10;
//		a = a + 1;
//		a += 1;
//		a++;
		
//		a += 5;  // a = a + 5;
		
		a *= 5 + 3;   // a = a * 5 + 3;
		              // a = a * (5 + 3);
		
		System.out.println(a);
		
	}
}






