package day07;

public class Drink {
	String name;
	int price;
	int cal;
}