package day07;

public class DrinkTest {
	public static void main(String[] args) {
		Drink d1 = new Drink();
		
		Drink d2 = new Drink();
		
		System.out.println(d1.name);
		System.out.println(d1.price);
		System.out.println(d1.cal);
		
		d1.name = "콜라";
		d1.price = 1500;
		d1.cal = 327;
		
		System.out.println(d1.name);
		System.out.println(d1.price);
		System.out.println(d1.cal);

		// ??
		d2.name = "파인애플 주스";
		d2.price = 2500;
		d2.cal = 420;
		
		System.out.println(d2.name);    // 파인애플 주스
		System.out.println(d2.price);   // 2500
		System.out.println(d2.cal);     // 420
		
		Drink d3 = d1;
		d3.name = "핫식스";
		d1.price = 3000;
		
		System.out.println(d1.name + "," + d3.name);
		System.out.println(d1.price + "," + d3.price);
		
		
	}
}















