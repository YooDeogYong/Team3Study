package day07;

public class Bread {
	String name;
	int price;
}