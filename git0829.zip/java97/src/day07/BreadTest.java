package day07;

import java.util.Scanner;

public class BreadTest {
	public static void main(String[] args) {
		Bread[] arr = new Bread[2];
		int pos = 0;
		
		Scanner sc = new Scanner(System.in);
		outer: 
		while (true) {
			
			if (pos == arr.length) {
				Bread[] temp = new Bread[pos * 2];
				System.arraycopy(arr, 0, temp, 0, pos);
				arr = temp;
			}
			
			Bread b = new Bread();
			System.out.print("빵의 이름을 입력하세요 : ");
			b.name = sc.nextLine();
			
			System.out.print("빵의 가격을 입력하세요 : ");
			b.price = Integer.parseInt(sc.nextLine());
			
			arr[pos++] = b;
			
			System.out.print("정보 입력을 계속 하시겠습니까?(0. 종료)");
			String isContinue = sc.nextLine();
			switch (isContinue) {
			case "0":
				break outer;
			}
		}
		
		System.out.println("----------------------");
		System.out.println("이름\t가격");
		System.out.println("----------------------");
		for (int i = 0; i < pos; i++) {
			Bread b = arr[i];
			System.out.println(b.name + "\t" + b.price);
		}
		System.out.println("----------------------");
		
	}
}









