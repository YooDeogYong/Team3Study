/*
 *   출력스트림 사용하기
 *   OutputStream(byte), Writer(char)
 */
package day15;

import java.io.FileWriter;

public class Test07 {
	public static void main(String[] args) {
		// 파일에 출력한다.
//		FileOutputStream fos = null;
		FileWriter fos = null;
		try {
			// 지정된 파일이 존재하지 않은 경우 파일을 생성하고
			// 존재한다면 내용을 덮어쓴다.
			// 만약, 기존 내용에 추가하고 싶다면
			// 객체를 생성시 생성자에 추가 옵션을 true로 설정해야 한다.
//			fos = new FileOutputStream("data/day15/test07.txt");
//			fos = new FileWriter("data/day15/test07.txt");
			fos = new FileWriter("data/day15/test07.txt", true);
			fos.write(97);
			fos.write('a');
			fos.write('9');
			fos.write('7');
			fos.write('가');
			System.out.println("test07.txt 파일에 내용이 쓰여졌습니다.");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}













