package day15;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Random;

public class Test12 {
	public static void main(String[] args) {
		// try with resources - 자동 닫기(AutoClose), 1.7 버전 추가
		try (
				FileWriter fw = new FileWriter("data/day15/test11.txt");
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter pw = new PrintWriter(bw);
		) {
			System.out.println("파일 내용 출력 시작");
			String[] msg = {"hello", "hi", "Good morning"};
			String[] name = {"a", "b", "c", "d", "e"};
			Random r = new Random();
			for (int i = 1; i <= 100; i++) {
				pw.printf(
						"%d. %s님 %s\n", 
						i,
						name[r.nextInt(name.length)],
						msg[r.nextInt(msg.length)]);
			}
			System.out.println("처리 완료");
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}












