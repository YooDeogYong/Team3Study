package day15;

import java.io.File;
import java.util.Arrays;

public class Test02 {
	public static void main(String[] args) {
		File f = new File("data/day15");
//		File f = new File("data/day15/aa.txt");
		if (f.exists()) {
			// 존재하는 경로가 파일인지 디렉토리인지 체크
			if (f.isDirectory()) {
				System.out.println("디렉토리 경로임");
				// 디렉토리 하위에 있는 파일과 하위디렉토리의 이름
				String[] arr = f.list();
				System.out.println(Arrays.toString(arr));
			}
			if (f.isFile()) {
				System.out.println("파일 경로임");
			}
		}
		
	}
}











