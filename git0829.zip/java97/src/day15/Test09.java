package day15;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Test09 {
	public static void main(String[] args) {
		// 파일 복사하기
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			fis = new FileInputStream("data/day15/Kalimba.mp3");
			fos = new FileOutputStream("data/day15/Kalimba2.mp3");
			System.out.println("복사 시작...");
			long s = System.currentTimeMillis();
			byte[] buffer = new byte[1024 * 32];
			while (true) {
				// ch : buffer에 읽어들인 바이트의 수 반환
				int ch = fis.read(buffer);
				if (ch == -1) break;
				// buffer 배열의 내용을 0번째 인덱스부터 ch 크기 만큼 출력
				fos.write(buffer, 0, ch);
			}
			double time = (System.currentTimeMillis() - s) / 1000d;
			System.out.println("파일 복사 완료 : " + time);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (fos != null) {
				try {
					fos.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}












