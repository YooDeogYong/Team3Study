/*
 *   File : 파일의 기본 정보를 추출할 수 있는 클래스
 *        : 파일과 연관된 기본 작업을 처리(생성, 삭제 등...)
 */
package day15;

import java.io.File;

public class Test01 {
	public static void main(String[] args) {
		File f = new File("data/day15/a/b");   // 파일 정보 : 디렉토리, 파일
		
		// 지정된 경로의 파일이 존재하는지 확인
		boolean result = f.exists();
		System.out.println(result);
		if (result) {
			System.out.println("존재하는 경로...");
		}
		else {
			// 존재하지 않는 경로일 경우 디렉토리 생성하기
			// mkdir  : 하나의 디렉토리 생성
			// mkdirs : 여러개의 디렉토리 생성
//			if (f.mkdir()) {
			if (f.mkdirs()) {
				System.out.println("디렉토리 생성");
			}
			else {
				System.out.println("디렉토리 생성 실패");
			}
		}
	}
}












