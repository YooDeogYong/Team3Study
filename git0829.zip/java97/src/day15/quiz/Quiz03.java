package day15.quiz;

public class Quiz03 {
	public static void main(String[] args) {
		try {
			/*
			 *  data/day15/aa.txt의 파일을 data/day15/a/b/acopy.txt로 복사한다.
			 *  만약, acopy.txt 파일이 복사될 data/day15/a/b 디렉토리가 존재하지 않는다면
			 *  디렉토리를 생성 후 파일을 복사한다.
			 */
			FileUtil.copy("data/day15/aa.txt", "data/day15/a/b/acopy.txt");
			System.out.println("복사성공");
			
			// data/day15/aa.txt 파일의 내용을 data/day15/a/b가 디렉토리 일경우 해당 디렉토리 아래로 동일한 aa.txt 이름으로 복사한다.
			FileUtil.copy("data/day15/aa.txt", "data/day15/a/b");
			
		} catch (Exception e) {
			System.out.println("파일 복사중 오류 발생");;
		}
	}
}
