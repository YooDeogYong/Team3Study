package day15.quiz;

import java.io.File;

public class Quiz02 {
	public static void main(String[] args) {
		/*
		 	File f = new File(경로);
		 	만약, 경로 부분이 data/day15일 경우 지정된 디렉토리 하위의 정보를 
		 	아래와 같이 출력하는 프로그램 작성
		 	--------------------------------
			file : a.txt
			file : b.txt
			directory : lec01
			file : Test.java	
		 	--------------------------------
		 */	
		/*
		File f = new File("data/day15");
		String[] arr = f.list();
		for (String name : arr) {
			File sub = new File(f.getPath() + "/" + name);
			System.out.printf("%s : %s\n", sub.isFile() ? "file" : "direction", name);
		}
		 */
		
		/*
		String path = "data/day15";
		for (String name : new File(path).list()) {
			System.out.printf(
				"%s : %s\n", 
				new File(path + "/" + name).isFile() ? "file" : "direction", 
				name
			);
		}
		*/
		/*
		File f = new File("data/day15");
		File[] arr = f.listFiles();
		for (File sub : arr) {
			System.out.printf(
					"%s : %s\n", 
					sub.isFile() ? "file" : "direction", 
					sub.getName()
			);
		}
		 */
		
		for (File sub : new File("data/day15").listFiles()) {
			System.out.printf(
					"%s : %s\n", 
					sub.isFile() ? "file" : "direction", 
					sub.getName()
			);
		}
	}
}





