package day15;

import java.io.File;

public class Test03 {
	public static void main(String[] args) {
		File f = new File("data/day15/test.txt");
		if (f.exists()) {
			// 지정된 경로의 파일 삭제
			if (f.delete()) {
				System.out.println("파일 삭제 성공");
			}
			else {
				System.out.println("파일 삭제 실패");
			}
		}
		else {
			// 경로에 해당하는 파일을 생성
			try {
				if (f.createNewFile()) {
					System.out.println("생성 성공");
				}
				else {
					System.out.println("생성 실패");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}












