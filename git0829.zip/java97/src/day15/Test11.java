package day15;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Random;

public class Test11 {
	public static void main(String[] args) {
		FileWriter fw = null;
		BufferedWriter bw = null;
		PrintWriter pw = null;
		
		try {
			fw = new FileWriter("data/day15/test11.txt");
			bw = new BufferedWriter(fw);
			pw = new PrintWriter(bw);
			System.out.println("파일 내용 출력 시작");
			String[] msg = {"hello", "hi", "Good morning"};
			String[] name = {"a", "b", "c", "d", "e"};
			Random r = new Random();
			for (int i = 1; i <= 100; i++) {
				// 1. a님 hello
				// 2. c님 Good morning
				/*
				bw.write(
						i + ". " + name[r.nextInt(name.length)] + "님 " + 
						msg[r.nextInt(msg.length)] + "\n");
				*/
				pw.printf(
						"%d. %s님 %s\n", 
						i,
						name[r.nextInt(name.length)],
						msg[r.nextInt(msg.length)]);
			}
			System.out.println("처리 완료");
			
			// close() 메서드가 실행할 때 버퍼의 내용을 
			// flush() 한다.
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pw != null) {
				try {
					pw.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (bw != null) {
				try {
					bw.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (fw != null) {
				try {
					fw.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
	}
}












