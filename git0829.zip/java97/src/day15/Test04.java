package day15;

import java.io.File;

public class Test04 {
	public static void main(String[] args) {
		File f = new File("data/day15/aa.txt");
		// 파일의 바이트 단위의 크기 가져오기
		long size = f.length();
		System.out.println("파일의 크기(byte) : " + size);
		
		// 파일 이름
		// 파일의 부모 디렉토리
		// 전체 경로
		String name = f.getName();
		String parent = f.getParent();
		String path = f.getPath();
		System.out.println("name : " + name);
		System.out.println("parent : " + parent);
		System.out.println("path : " + path);
	}
}












