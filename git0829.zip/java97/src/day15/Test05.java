package day15;

import java.io.InputStream;
import java.io.InputStreamReader;

public class Test05 {
	public static void main(String[] args) {
		System.out.println((int)'\r');
		System.out.println((int)'\n');
//		InputStream in = System.in;
		// 한글처리를 위해서는 바이트 단위를 문자 단위 처리로 변경
		InputStream in = System.in;
		InputStreamReader isr = new InputStreamReader(in);
		try {
			/*
			int ch = in.read();
			System.out.println(ch);
			ch = in.read();
			System.out.println(ch);
			ch = in.read();
			System.out.println(ch);
			ch = in.read();
			System.out.println(ch);
			*/
			while (true) {
				int ch = isr.read();
//				System.out.print(ch);
				System.out.print((char)ch);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}










