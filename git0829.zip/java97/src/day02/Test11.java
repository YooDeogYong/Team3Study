package day02;

public class Test11 
{
	public static void main(String[] args) 
	{
		Test01 t01 = new Test01();
		System.out.println(t01);
	}
}
