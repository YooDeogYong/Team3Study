package day02;
import java.util.Random;

public class Test09 
{
	public static void main(String[] args) 
	{
		int i = Integer.parseInt("100");
		int k = Integer.parseInt("200");
		
		System.out.println(i);
		System.out.println(k);
		System.out.println(Integer.MAX_VALUE);

		Random r = new Random();
		int num = r.nextInt(100);
		System.out.println(num);
	}
}
