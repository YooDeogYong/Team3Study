package day10;

public class Test03 {
	public static void main(String[] args) {
		System.out.println("메인 시작");
		System.out.println(Sub03.k);
		Sub03 s03;
		s03 = new Sub03();
		Sub03 s04 = new Sub03();
		System.out.println("메인 종료");
	}
}












