package day10;

public class ExDate {
	private int year;
	private int month;
	private int date;
	public ExDate(int year, int month, int date) {
		this.year = year;
		this.month = month;
		this.date = date;
	}

	public ExDate(/* ExDate this */) {
		this(2013, 4, 1);
		/*
		ExDate(2013, 4, 1);
		
		this.year = 2013;
		this.month = 4;
		this.date = 1;
		*/
	}

	private String pad(String ch, int val) {
		if (val < 10) return ch + val;
		return String.valueOf(val);
	}
	
	public void showDate() {
		System.out.printf("%d년 %d월 %s일\n", year, month, pad("^", date));
	}

}	
















