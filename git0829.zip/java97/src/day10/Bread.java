package day10;

public class Bread {
	private String name;
	private int price;
	
	// 클래스에 생성자가 없는 경우 제공되는 디폴트 생성자 형태
//	public Bread() {}
	
	// 생성자 메서드 선언
	Bread(/* Bread this, */String name, int price) {
		this.name = name;
		this.price = price;
	}
	
	Bread(String name) {
		this(name, 1000);
		/*
		this.name = name;
		this.price = 1000;
		*/
	}
	Bread() {
		// Bread(String n) 생성자 호출
//		Bread("단팥");  // 오류
//		this("단팥");
		this("소보루", 1500);
		/*
		this.name = "소보루";
		this.price = 1500;
		*/
	}
//	Bread(int price) {
//		System.out.println("Bread(int price) 생성자 호출");
//	}
	public String getName() {
//		this();
		return name;
	}
	public void setName(String name) {
		// 인스턴스 변수 호출
		this.name = name;
	}
	
	public void call() {}
	
	public int getPrice() {
		// 인스턴스 메서드 호출
		call();
		this.call();
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
}







