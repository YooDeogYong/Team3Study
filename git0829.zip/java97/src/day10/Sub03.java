package day10;

public class Sub03 {
	
	/*
	 *  static 블럭
	 *  - 클래스 로딩시점에 실행
	 *  - 클래스 정보가 로딩되는 시점은 사용하기 전에...
	 */
	static int k = 100;
	static {
		System.out.println("클래스 정보 로딩됨");
	}
	Sub03() {
		System.out.println("생성자 호출됨");
	}
}

	
	
	
	
	
	
	
	
	