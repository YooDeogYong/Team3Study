package day10;

public class Test02 {
	
	static String sMsg = "static 변수";
	public static void call() {}
	
	String msg = "nonstatic";
	public void test() {     // nonstatic method, instance method
		// nonstatic 에서 static 으로 선언된 
		// 변수 또는 메서드를 접근할 수 있다.
		System.out.println(sMsg);
		call();
	}
	
	public static void main(String[] args) {  // static method, class method
		/* 
		 * 같은 클래스내의 변수 또는 메서드라도 
		 * 인스턴스를 만들고 나서 접근 할 수 있다.
		 */
		Test02 t02 = new Test02();
		t02.test();
		System.out.println(t02.msg);
		
		Sub02 s02 = new Sub02();
		System.out.println(s02.i);
		System.out.println(s02.k);
		System.out.println(Sub02.k);
	}
}










