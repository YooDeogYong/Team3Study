/*
 *   생성자 메서드
 *   1. new와 함께 호출, 객체 생성후 호출 불가능
 *   2. 클래스명과 이름이 동일, 반환타입 (X)
 *   3. 디폴트 생성자
 *      - 개발자가 클래스 정의시 명시적으로 생성자를 정의하지 않은 경우
 *        컴파일러가 컴파일시에 기본으로 제공하는 생성자
 *        형태 : 클래스명() {} 
 *   4. 용도
 *      객체가 생성될 때 갖춰야할 초기값들을 설정할 때 주로 사용  
 *   5. this 의 이해..
 *      - 생성된 객체를 나타내는 또 다른 별칭
 *      - static 이 붙지 않은 모든 메서드에 숨겨져 있는 히든 변수    
 *      - this.변수 -> 인스턴스 변수
 *        this.메서드 -> 인스턴트 메서드
 *        
 *        this([값1, ...]) -> 생성자 메서드 호출
 *          - 생성자 메서드 내에서만 사용가능함, 일반 메서드 사용 불가
 *          - 생성자 메서드 내에서 가장 위쪽에 선언되어야 한다. 
 */ 
package day10;

public class Test01 {
	public static void main(String[] args) {
		
		Bread b1 = new Bread();
		b1.setName("소보루");
		b1.setPrice(1500);
		
		Bread b2 = new Bread("소보루", 1500);

		Bread b3 = new Bread("단팥빵", 2000);
		
//		Bread b2 = new Bread("소보루");
//		Bread b3 = new Bread(1500);
	}
}









