package day10;
/*
 *  제공된 코드는 변경하지 않는다.
 *  코드를 추가할 수 있다.
 *  단, 생성자는 추가할 수 없다.
 */
public class Quiz01 {
//	public static Quiz01 quiz = new Quiz01();
	private static Quiz01 quiz;
	// Singleton Pattern
	public static Quiz01 getInstance() {
		if (quiz == null) {
			quiz = new Quiz01();
		}
		return quiz;
	}
	
	private Quiz01() {}
	public void msg() {
		System.out.println("성공");
	}
}







