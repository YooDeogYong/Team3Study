package day10;

public class Test04 {
	public static void main(String[] args) {
		Sub04 s1 = new Sub04();
		Sub04 s2 = new Sub04();
		s1.i = 200;
		s1.k = 400;
		s2.i = 300;
		s2.k = 800;
		Sub04.k = 1000;
		System.out.println(s1.i + "," + s1.k);
		System.out.println(s2.i + "," + s2.k);
	}
}











