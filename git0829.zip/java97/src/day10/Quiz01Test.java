package day10;

public class Quiz01Test {
	public static void main(String[] args) {
		// 실행 시 "성공" 이 출력되면 됨...
		Quiz01 q01 = Quiz01.getInstance();
		q01.msg();
	}
}
