package day10;

public class Sub04 {
	int i = 100;
	static int k = 200;
}
