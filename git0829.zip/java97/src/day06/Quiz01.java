package day06;

import java.util.Arrays;

public class Quiz01 {
	public static void main(String[] args) {
		int[] arr = {5, 1, 7, 8, 3, 1, 8};
		
		// 배열을 새롭게 생성하지 않은 상태에서 아래의 결과가 나오도록
		// 코드 작성
		
		//  크기 : 4
		//  0       -      3
		//  1       -      2
		
		//  크기 : 7
		//  0       -      6  ->  7 - 1 - 0
		//  1       -      5  ->  7 - 1 - 1
		//  2       -      4  ->  7 - 1 - 2
		for (int i = 0; i < arr.length / 2; i++) {
			int loc = arr.length -1 - i;
			int temp = arr[i];
			arr[i] = arr[loc];
			arr[loc] = temp;
		}

		// 8, 7, 1, 5
		System.out.println(Arrays.toString(arr));
	}
}








