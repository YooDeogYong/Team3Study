package day06;

import java.util.Scanner;

public class Quiz02 {
	public static void main(String[] args) {
		int [] arr = {5, 1, 8, 9, 11};
		
		// 수를 입력하세요 : 6
		// 6보다 큰 수의 합은 28입니다.
		
		Scanner sc = new Scanner(System.in);
		System.out.print("수를 입력하세요 : ");
		int num = Integer.parseInt(sc.nextLine());
		System.out.println("num : " + num);
		
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			/*
			if (num < arr[i]) {
				sum += arr[i];
			}
			*/
			if (num >= arr[i]) continue;

			sum += arr[i];
		}
		System.out.printf("%d보다 큰 수의 합은 %d입니다.", num, sum);
	}
}









