package day06;

import java.util.Arrays;

public class Test01 {
	public static void main(String[] args) {
		int[] arr = {9, 2, 6, 7, 4};
		int temp = arr[1];
		
		arr[1] = arr[3];
		
		arr[3] = temp;
		
		System.out.println(Arrays.toString(arr));
	}
}













