package day06;

import java.util.Arrays;
import java.util.Scanner;

public class Test02 {
	public static void main(String[] args) {
		int [] arr = new int[2];
		// 새로운 값이 입력될 위치
		int pos = 0;
		
		System.out.println("배열의 크기 : " + arr.length);
		
		Scanner sc = new Scanner(System.in);
		
		outer:
		while (true) {
			System.out.println("-----------------");
			System.out.println("1. 등록");
			System.out.println("0. 종료");
			System.out.println("-----------------");
			System.out.print("메뉴 : ");
			String menu = sc.nextLine();
			switch (menu) {
			case "1":
				// 배열이 꽉 찼다면 배열의 크기를 늘리는 작업 진행
				if (arr.length == pos) {
					// 새로운 배열 생성
					int[] temp = new int[pos * 2];
					// 기존 배열의 내용 복사
					System.arraycopy(arr, 0, temp, 0, pos);
					
					arr = temp;
				}
				
				System.out.print("입력값 : ");
				arr[pos++] = Integer.parseInt(sc.nextLine());
				break;
			case "0":
				break outer;
			}
		}
		
		System.out.println("입력된 배열의 요소");
		System.out.println(Arrays.toString(arr));
	}
}






