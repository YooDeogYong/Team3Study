package day05;

public class Test03 {
	public static void main(String[] args) {
		// 배열의 생성
		int[] arr = new int[3];
		// 값의 대입
		arr[0] = 1;
		arr[1] = 2;
		arr[2] = 3;
		
		// 배열의 특정값 초기화 시키기
		int[] arr2 = {1, 2, 3};
//		arr2 = {4, 5, 6};  // 배열의 선언과 동시에 사용가능
		
		int[] arr3 = new int[]{1, 2, 3, 4};
		arr3 = new int[]{4, 5, 6};
		
	}
}









