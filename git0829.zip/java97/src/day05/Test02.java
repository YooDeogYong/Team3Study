/*
 *   배열의 초기화
 *   - 공간이 생성될 때 값의 자동 초기화가 발생함... 
 *   - 정수 : 0, 실수 : 0.0, 논리형 : false, 문자 : 공백
 *   - 참조형 : null (나는 아직 주소가 없어요)
 *   
 *   배열의 크기
 *   - 배열명.length
 */
package day05;

public class Test02 {
	public static void main(String[] args) {
		int[] arr;
		arr = new int[2];
		
//		System.out.println(arr[0]);
//		System.out.println(arr[1]);
//		System.out.println(arr[2]);
		
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		
		// boolean을 담을수 있는 배열을 선언하고
		// 배열의 이름을 arr2로 지정한다.
		// 크기는 3개를 생성한다.
		// 생성된 배열의 초기값을 반복문을 이용해서 확인하자..
		
		boolean [] arr2 = new boolean[3];
		
		for (int i = 0; i < arr2.length; i++) {
			System.out.println(arr2[i]);
		}
		
		String[] arr3 = new String[2];
		arr3[1] = "홍길동";
		
		for (int i = 0; i < arr3.length; i++) {
			System.out.println(arr3[i]);
		}
		
	}
}














