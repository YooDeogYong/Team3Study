/*
 *  배열
 *  
 *  여러개의 동일한 데이터타입의 값들을 하나의 변수를
 *  통해서 관리하는 자료구조
 */
package day05;

import java.util.Random;

public class Test01 {
	public static void main(String[] args) {
		Random [] arr = new Random[3];
		arr[0] = new Random();
		arr[1] = new Random();
		arr[2] = new Random();
		
//		Random r1 = new Random();
		
		/*
		int [] arr = new int[3];
		arr[0] = 100;
		arr[1] = 200;
		arr[2] = 300;
		*/
		
		/*
		String name1 = "홍길동";
		String name2 = "강철수";
		
		String [] arr = new String [2];
		*/
	}
}




























