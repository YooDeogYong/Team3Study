/*
 *   배열의 내용을 확인방법 
 */
package day05;

import java.util.Arrays;

public class Test04 {
	public static void main(String[] args) {
		int[] arr = {1, 2, 3};
		
		System.out.println(arr);
		
		System.out.println("-------------------------");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		System.out.println("-------------------------");
		// 1.5 버전부터 향상된 for
		for (int val : arr) {
			System.out.println(val);
		}
		System.out.println("-------------------------");
		
		String[] sArr = {"a", "b", "c"};
		for (String val : sArr) {
			System.out.println(val);
		}
		System.out.println("-------------------------");
		/*
		String data = Arrays.toString(sArr);
		System.out.println(data);
		 */
		System.out.println(Arrays.toString(sArr));
		
		
	}
}

















