package day05.exam;

import java.util.Scanner;

public class Test02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("수를 입력하세요 : ");
		int begin = sc.nextInt();
		
		System.out.print("수를 입력하세요 : ");
		int end = sc.nextInt();

		int sum = 0;
		for (int i = begin; i <= end; i++) 
			sum += i;
		
		System.out.printf("%d 부터 %d까지의 합은 %d입니다.", begin, end, sum);
	}
}
