package day05.exam;

import java.util.Random;

public class Test11 {

	public static void main(String[] args) {
		Random r = new Random();
		for (int i = 1, k = 1; i <= 5; i++, k = 1) {
			System.out.printf("Set %d : ", i);			
			for ( ; k <= 6; k++) {
				System.out.printf("%3d", r.nextInt(45) + 1);
			}
			System.out.println();
		}	
	}

}
