package day05.exam;

import java.util.Scanner;

public class Test05 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("수를 입력하세요 : ");
		int num = sc.nextInt();
		
		int divisorSum = 0;
		for (int i = 1; i <= num / 2; i++) {
			if (num % i == 0) divisorSum += i;
		}
		
		System.out.printf("%d은 %s"
				          , num
				          , divisorSum == num ? "완전수입니다." : "완전수가 아닙니다.");
		
	}
}
