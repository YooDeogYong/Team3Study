package day05.exam;

import java.util.Random;

public class Test09 {

	public static void main(String[] args) {
		int nPrimes = new Random().nextInt(11) + 10;

		Outer: for (int i = 2;; i++) {
			for (int j = 2; j < i; j++) {
				if (i % j == 0)
					continue Outer;
			}

			System.out.print(i + " ");
			if (--nPrimes == 0)
				break;
		}
	}

}
