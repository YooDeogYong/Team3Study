package day05.exam;

import java.util.Random;

public class Test03 {
	public static void main(String[] args) {
		Random ran = new Random();
		int sum = 0;
		
		System.out.print("생성된 숫자 : ");
		// 5개의 랜덤한 숫자를 생성하고 생성된 숫자를 sum 변수에 더한다.
		for(int i = 0; i < 5; i++) {
			int ranNum = ran.nextInt(100) + 1; 
			sum += ranNum;
			System.out.print(ranNum + " ");
		}
		System.out.println();
		System.out.println("1 - 100사이의 랜덤 숫자 5개의 합계 : " + sum);
		System.out.println("1 - 100사이의 랜덤 숫자 5개의 평균 : " + sum/5.0);
	}
}
