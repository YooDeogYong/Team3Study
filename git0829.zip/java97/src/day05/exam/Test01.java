package day05.exam;

public class Test01 {
	public static void main(String[] args) {
		for (int i = 1; i <= 100; i++) 
			System.out.print(i + ((i % 10) == 0 ? "\n" : "\t"));	
	}
}
