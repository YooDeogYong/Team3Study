package day05.exam;

import java.util.Scanner;

public class Test12 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("줄을 입력하세요 : ");
        final int LINE = Integer.parseInt(sc.nextLine());
        for (int i = 1; i <= LINE; i++) {
            for (int k = 1; k <= LINE - i; k++) {
                System.out.print(" ");
            }
            for (int k = 1; k < i * 2; k++) {
                System.out.print('*');
            }
            System.out.println();
        }
        for (int i = 1; i < LINE; i++) {
            for (int k = 1; k <= i; k++) {
                System.out.print(" ");
            }
            for (int k = 1; k <= (LINE - i) * 2 - 1; k++) {
                System.out.print('*');
            }
            System.out.println();
        }
    }


}
