package day05.exam;

import java.util.Scanner;

public class Test10 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.print("출력할 행의 수를 입력하세요(1-10) : ");
		int row = s.nextInt();
		
		System.out.print("출력할 열의 수를 입력하세요(1-10) : ");
		int column = s.nextInt();
		
		int count = 1;
	    while (row >= 1) {
	    	while (count <= column) {
	            System.out.print(row % 2 == 1 ? '<' : '>');
	            count++;
	        }
	        row--;
	        count = 1;
	        System.out.println();
	    }
	}

}
