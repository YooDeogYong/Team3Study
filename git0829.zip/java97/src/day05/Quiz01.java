package day05;

public class Quiz01 {
	public static void main(String[] args) {
		int[] source = {1, 2, 3, 4, 5};
		// dest 배열을 선언하고
		// source 배열의 내용을 dest 배열에 복사하는 코드를 작성
		// source 배열의 2번째 인덱스부터 2개를
		// dest 배열의 1번째 인덱스 위치로 복사한다.
		// 출력형식>
		// source 배열 : 1 2 3 4 5
		// dest 배열 : 0 3 4 0 0
		
//		dest[1] = source[2];
//		dest[2] = source[3];
		
		int[] dest = new int[source.length];
		
//		System.arraycopy(source, 2, dest, 1, 2);
		System.arraycopy(source, 0, dest, 0, source.length);
		/*
		for (int i = 1; i <= 2; i++) {
			dest[i] = source[i + 1];
		}
		*/
		
		System.out.print("source : ");
		for (int i = 0; i < source.length; i++) {
			System.out.print(source[i] + " ");
		}
		System.out.println();
		System.out.print("dest : ");
		for (int i = 0; i < dest.length; i++) {
			System.out.print(dest[i] + " ");
		}
		
		
	}
}






