package day05;

import java.util.Scanner;

public class Quiz03 {
	public static void main(String[] args) {
		/*
		 *    수를 입력하세요 : 3
		 *    배열에 0개가 있습니다.
		 *    
		 *    수를 입력하세요 : 2
		 *    배열에 1개가 있습니다.
		 *    
		 *    수를 입력하세요 : -1
		 *    종료합니다.
		 */
		Scanner sc = new Scanner(System.in);
		
		int[] arr = {9, 2, 6, 7, 4};
		while (true) {
			System.out.print("수를 입력하세요 : ");
			int num = Integer.parseInt(sc.nextLine());
			if (num == -1) break;
			
			int count = 0;
			for (int val : arr) {
				if (num == val) {
					count++;
				}
			}
			System.out.printf("배열에 %d개가 있습니다.\n", count);
		}
		System.out.println("종료합니다.");
		
	}
}













