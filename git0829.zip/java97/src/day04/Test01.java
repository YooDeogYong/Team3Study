/*
 *   조건문 : if
 *   
 */
package day04;

import java.util.Random;

public class Test01 {
	public static void main(String[] args) {
		System.out.println("참일 경우 실행");
		
		Random r = new Random();
		int num = r.nextInt(10) + 1;
		System.out.println("생성된 수 : " + num);

		// 생성된 수가 5보다 큰 경우만 화면에 다음과 같이 출력
		// 생성된 수는 5보다 큽니다.(참일 경우)
		if (num > 5)
			System.out.println("생성된 수는  5보다 큽니다.");
		
		if (num > 5) {
			System.out.println("참인 경우  실행되는 내용");
			System.out.println("생성된 수는  5보다 큽니다.");
		}
		
		if (num % 2 == 0) {
			System.out.println("짝수");
		}
		else {
			System.out.println("홀수");
		}
		
		/*
		 * 생성된 수가 5일 경우 : 5입니다.
		 * 생성된 수가 5보다 작을 경우 : 5보다 작습니다.
		 * 생성된 수가 5보다 클 경우 : 5보다 큽니다.
		 */
		// 5보다 큰 경우
		if (num > 5) {
			System.out.println("5보다 큽니다.");
		}
		// 작거나 같은 경우
		else {
			// 같은 경우
			if (num == 5) {
				System.out.println("5입니다.");
			}
			// 작은 경우
			else {
				System.out.println("5보다 작습니다.");
			}
		}
			
		if (num > 5) {
			System.out.println("5보다 큽니다.");
		}
		else if (num == 5) {
			System.out.println("5입니다.");
		}
		else {
			System.out.println("5보다 작습니다.");
		}
		String result;
		if (num > 5) {
			result = "5보다 큽니다.";
		}
		else if (num == 5) {
			result = "5입니다.";
		}
		else {
			result = "5보다 작습니다.";
		}
		System.out.println(result);
	}
}













