/*
	break, continue
	
	break - 반복문을 빠져나감
	continue - 현재 반복을 스킵
 */
package day04;

public class Test04 {
	public static void main(String[] args) {
		int num = 5;
		for (int i = 1; i <= 10; i++) {
			if (num == i) {
//				break;
				continue;
			}
			System.out.println(i);
		}
	}
}
