/*
 *   조건문 : switch
 *   if문과 switch 문의 차이점 : switch문은 (==)비교만 가능
 *   
 *   주의점.
 *   - break가 없을 경우 조건에 맞는 case만 실행하는 것이 아니라
 *     밑으로 진행하면서 모든 case를 실행한다.
 *   - switch 문의 수식에는 아래와 같은 것들만 입력될 수 잇다.
 *     1.4버전 까지 : byte, short, char, int만 가능
 *     1.5버전 : enum 타입 추가됨
 *     1.7버전 : String 타입이 추가됨  
 *   
 *   switch (수식) {
 *   case 값1:
 *   	수식과 값이 동일하다면 처리할 문장을 작성
 *      [break;]  // switch 블럭을 빠져 나감
 *   case 값2:
 *   	수식과 값이 동일하다면 처리할 문장을 작성
 *      [break;]  // switch 블럭을 빠져 나감
 *   default:
 *      위의 수식과 값이 일치하는 것이 하나도 없을 경우 실행
 *   }
 */
// ctrl + shift + o : 자동 import
// import 클래스의 이름뒤에 커서를 위치하고
// ctrl + space 후 import 선택
package day04;

import java.util.Random;

public class Test02 {
	public static void main(String[] args) {
		Random r = new Random();
		int num = r.nextInt(5) + 1;
		System.out.println("생성된 수 : " + num);
		// 생성된 수가
		// 1일 경우 화면에 10을 더한 값을 출력
		// 2일 경우 화면에 100을 더한 값을 출력
		// 3일 경우 화면에 1000을 더한 값을 출력
		// 나머지 경우(4, 5)에는 10000을 더한값을 출력
		switch (num) {
		case 1:
			System.out.println(num + 10);
			break;
		case 2:
			System.out.println(num + 100);
			break;
		case 3:
			System.out.println(num + 1000);
			break;
		default:
			System.out.println(num + 10000);
		}
	}
}





















