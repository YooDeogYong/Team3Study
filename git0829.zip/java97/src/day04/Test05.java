/*
 	while 
 	
 	for :  초기값 -> 조건식 -> 실행문장 -> 증감
 	             -> 조건식 ...........
 	
 	초기값..
 	while (조건식) {
 		실행문장
 		증감
 	}
  
 */
package day04;

public class Test05 {
	public static void main(String[] args) {
		/*
		for (int i = 1; i <= 10; i++) {
			System.out.println(i);
		}
		for (int i = 1; i <= 10; i++) {
			System.out.println(i);
		}
		
		
		int i = 1;
		while (i <= 10) {
			System.out.println(i);
			i++;
		}
		
		i = 1;
		while (i <= 10) {
			System.out.println(i);
			i++;
		}
		System.out.println(i);
		 */
		int i = 1;
		for ( ; i <= 10; i++) {
			System.out.println(i);
		}
		
		for (i = 1; i <= 10; i++) {
			System.out.println(i);
		}
		
		for (i = 1; ; i++) {
			System.out.println(i);
			if (i >= 10) {
				break;
			}
		}

		for (i = 1; ; ) {
			System.out.println(i);
			i++;
			if (i >= 10) {
				break;
			}
		}
		
		// 무한반복됨..
		/*
		for ( ; ; ) {
			System.out.println("무한반복...");
		}
		*/
	}
}











