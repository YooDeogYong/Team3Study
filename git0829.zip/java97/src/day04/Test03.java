/*
 *   반복문 : for
 *   
 *   for (1. 초기값 설정; 2. 조건식; 3. 값의증감) {
 *   	4. 조건식이 참일 경우에 실행할 문장
 *   }
 *   5. for 문을 벗어남
 *   
 *   1 - 2(참) - 4 - 3
 *     - 2(참) - 4 - 3
 *     - 2(참) - 4 - 3
 *     .........
 *     - 2(거짓) - 5
 *   
 */
package day04;

public class Test03 {
	public static void main(String[] args) {
		for (int i = 0; i < 2; i++) {
			System.out.println(i);
		}
		
		/*
			실행문장                             i값        
			int i = 0                0
			i < 2(참)                0
			System.out.println(i);   0
			i++                      1
			i < 2(참)                1
			System.out.println(i);   1
			i++                      2
			i < 2(거짓)              2
			
		 */
		
		System.out.println(1);
		System.out.println(2);
		System.out.println(3);
		System.out.println(4);
		System.out.println(5);
		
		for (int i = 1; i <= 5; i++) {
			System.out.println(i);
		}
		
		System.out.println(1);
		System.out.println(3);
		System.out.println(5);
		System.out.println(7);
		System.out.println(9);
		
		for (int i = 1; i <= 9; i += 2) {
			System.out.println(i);
		}
		
		for (int i = 1; i <= 5; i ++) {
			System.out.println(i * 2 - 1);
			
			// 1 * 2 -1   1
			// 2 * 2 -1   3
			// 3 * 2 -1   5
			// 4 * 2 -1   7
			// 5 * 2 -1   9
		}
		/*
			2 * 1 = 2
			2 * 2 = 4
			.........
			2 * 9 = 18
		 */
		/*
		for (int i = 1; i <= 9; i++) {
			System.out.printf("2 * %d = %d\n", i, 2 * i);
		}
		*/
		for (int dan = 2; dan <= 9; dan++) {
			for (int i = 1; i <= 9; i++) {
				System.out.printf(
						"%d * %d = %d\n", dan, i, dan * i);
			}
		}
	}
}






















