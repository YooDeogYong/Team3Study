package day04;

public class Test06 {
	public static void main(String[] args) {
		int num = 2;
		
		outer: 
		for (int i = 1; i < 3; i++) {
			for (int k = 1; k < 3; k++) {
				if (num == k) {
					break outer;
				}
				System.out.println(i + " - " + k);
			}
			
		}
	}
}
