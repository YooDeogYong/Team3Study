/*
    서울랜드 동물원에 놀러 갔습니다. 
    동물원 요금이 5세 미만은 무료, 5 - 11세 까지 2500원 
   12세 부터는 5000원 입니다.
    화면에서 나이를 입력 받아 요금을 계산하여 출력하는 프로그램을 작성하시오
    출력예시>
    나이를 입력하세요 :  3 
    입장료는 무료입니다.
    나이를 입력하세요 :  7 
    입장료는 2500원 입니다.
    나이를 입력하세요 :  22 
    입장료는 5000원 입니다.

 */
package day04;

import java.util.Scanner;

public class Quiz03 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("나이를 입력하세요 : ");
		int age = Integer.parseInt(sc.nextLine());
		String result;
		if      (age <   5) result = "무료";
		else if (age <= 11) result = "2500원";
		else                result = "5000원";
		System.out.printf("입장료는 %s 입니다.", result);
	}
}










