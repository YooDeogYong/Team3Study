package board.step03;

public class Board {
	int no;
	String title;
	String writer;
}
