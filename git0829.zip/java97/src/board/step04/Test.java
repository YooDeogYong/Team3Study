package board.step04;

import board.step04.ui.BoardUI;

public class Test {
	public static void main(String[] args) {
		new BoardUI().service();
	}
}







