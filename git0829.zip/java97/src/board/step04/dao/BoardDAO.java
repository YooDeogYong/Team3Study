/*
 *  insert모듈명, update모듈명, delete모듈명, select모듈명
 *  
 *  등록 : Create
 *  조회 : Read
 *  수정 : Update
 *  삭제 : Delete
 */
package board.step04.dao;

import board.step04.vo.Board;

public class BoardDAO {
	// 데이터 저장 위치
	int pos = 0;
	// 글번호 처리 
	int no = 0;
	// 게시글의 데이터를 저장하기 위한 배열 선언
	Board[] arr = new Board[5];
	
	public Board[] selectBoard() {
		Board[] rList = new Board[pos];
		System.arraycopy(arr, 0, rList, 0, pos);
		return rList;
	}
	public Board selectBoardByNo(int no) {
		for (int i = 0; i < pos; i++) {
			Board b = arr[i];
			if (no == b.getNo()) {
				return b;
			}
		}
		return null;
	}
	public void insertBoard(Board board) {
		// 배열에 데이터가 다 차게 되면 공간을 확장
		if (arr.length == pos) {
			Board[] temp = new Board[pos * 2];
			System.arraycopy(arr, 0, temp, 0, pos);
			arr = temp;
		}
		// 글번호 저장
		board.setNo(++no);
		arr[pos++] = board;
	}
	public void updateBoard(Board board) {
		for (int i = 0; i < pos; i++) {
			Board b = arr[i];
			if (board.getNo() == b.getNo()) {
				arr[i] = board;
				return ;
			}
		}
	}
	public boolean deleteBoard(int no) {
		int delNo = -1;
		for (int i = 0; i < pos; i++) {
			Board board = arr[i];
			if (no == board.getNo()) {
				delNo = i;
				break;
			}
		}
		
		if (delNo == -1) {
			return false;
		}
		
		// 삭제 처리
		// 1번과정 : 삭제할 글의 인덱스 찾기 : delNo
		// 2번과정 : 앞으로 몇개의 데이터를 당겨야 할지..
		// 3번과정 : pos의 데이터수 하나 줄이기
		// 4번과정 : 마지막 데이터 초기화
		int moveCnt = pos - 1 - delNo;
		if (moveCnt > 0) {
			System.arraycopy(arr, delNo + 1, arr, delNo, moveCnt);
		}
		pos--;
		arr[pos] = null;
		return true;
	}
}








