package board.step06.exception;

public class BoardException extends RuntimeException {
	public BoardException() {
	}
	public BoardException(String message) {
		super(message);
	}
		
}
