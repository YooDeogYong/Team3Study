package board.step06.ui;

import java.util.Scanner;

import board.step06.dao.BoardDAO;
import board.step06.exception.BoardException;

public class BoardUI {
	private Scanner sc = new Scanner(System.in);
	private BoardDAO dao = new BoardDAO();
	
	public int choiceMenu() {
		System.out.println("-------------------------");
		System.out.println("1. 전체 게시물 조회");
		System.out.println("2. 글번호 조회");
		System.out.println("3. 글등록");
		System.out.println("4. 글수정");
		System.out.println("5. 글삭제");
		System.out.println("0. 종료");
		System.out.println("-------------------------");
		System.out.print("메뉴 중 처리할 항목을 선택하세요 : ");
		return Integer.parseInt(sc.nextLine());
	}
	
	public void exitBoard() {
		System.exit(0);
	}
	
	public void service() {
		try {
			BaseUI ui = null;
			while (true) {
				switch (choiceMenu()) {
				case 1: ui = new ListUI(dao); break;
				case 2: ui = new DetailUI(dao); break;
				case 3: ui = new AddUI(dao); break;
				case 4: ui = new ModUI(dao); break;
				case 5: ui = new DelUI(dao); break;
				case 0: ui = new ExitUI();
				}
				ui.service(); 
			}
		} catch (BoardException e) {
			System.out.println("사용자 정의 예외...");
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}






