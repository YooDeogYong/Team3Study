package board.step06.ui;

public class ExitUI extends BaseUI {
	public void service() {
		System.exit(0);
	}
}
