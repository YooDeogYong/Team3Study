package board.step06.ui;

import java.text.SimpleDateFormat;

import board.step06.dao.BoardDAO;
import board.step06.exception.BoardException;
import board.step06.vo.Board;

public class DetailUI extends BaseUI {
	private BoardDAO dao;
	
	public DetailUI(BoardDAO dao) {
		this.dao = dao;
	}

	public void service() {
		System.out.print("조회할 글번호를 입력하세요 : ");
		int no = Integer.parseInt(sc.nextLine());
		System.out.println("---------------------------");
		
		Board b = dao.selectBoardByNo(no);
		if (b != null) {
			SimpleDateFormat sdf = 
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			System.out.println("번호 : " + b.getNo());
			System.out.println("제목 : " + b.getTitle());
			System.out.println("글쓴이 : " + b.getWriter());
			System.out.println("등록일시 : " + sdf.format(b.getRegDate()));
		}
		else {
			System.out.println(
					no + "번에 해당하는 데이터가 없습니다.");
		}
		System.out.println("---------------------------");
	}
}
