package board.step06.ui;

import board.step06.dao.BoardDAO;
import board.step06.vo.Board;

public class AddUI extends BaseUI {
	private BoardDAO dao;
	
	public AddUI(BoardDAO dao) {
		this.dao = dao;
	}

	public void service() {
		Board b = new Board();
		System.out.print("제목을 입력하세요 : ");
		b.setTitle(sc.nextLine());
		System.out.print("내용을 입력하세요 : ");
		b.setContent(sc.nextLine());
		System.out.print("글쓴이를 입력하세요 : ");
		b.setWriter(sc.nextLine());
		dao.insertBoard(b);
		System.out.println("게시글 등록이 완료되었습니다.");
	}
}
