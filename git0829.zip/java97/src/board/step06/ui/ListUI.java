package board.step06.ui;

import java.text.SimpleDateFormat;

import board.step06.dao.BoardDAO;
import board.step06.vo.Board;
import util.MyArrayList;

public class ListUI extends BaseUI {
	private BoardDAO dao;
	
	public ListUI(BoardDAO dao) {
		this.dao = dao;
	}

	public void service() {
		SimpleDateFormat sdf = 
				new SimpleDateFormat("yyyy-MM-dd");
		
		MyArrayList list = dao.selectBoard();
		
		System.out.println("------------------------");
		System.out.println("번호\t제목\t글쓴이\t등록일");
		System.out.println("------------------------");
		for (int i = list.size() - 1; i >= 0; i--) {
			Board b = (Board)list.get(i);	
			System.out.println(
				b.getNo() + "\t" + 
				b.getTitle() + "\t" + 
				b.getWriter() + "\t" +
				sdf.format(b.getRegDate())
			);
		}
		// 데이터가 존재하지 않는 경우
		if (list.isEmpty()) {
			System.out.println("게시글이 존재하지 않습니다.");
		}
		System.out.println("------------------------");
	}
}
