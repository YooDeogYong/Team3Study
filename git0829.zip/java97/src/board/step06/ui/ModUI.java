package board.step06.ui;

import board.step06.dao.BoardDAO;
import board.step06.vo.Board;

public class ModUI extends BaseUI {
	private BoardDAO dao;
	
	public ModUI(BoardDAO dao) {
		this.dao = dao;
	}

	public void service() {
		System.out.print("수정할 글번호를 입력하세요 : ");
		int no = Integer.parseInt(sc.nextLine());
		Board board = dao.selectBoardByNo(no);
		if (board == null) {
			System.out.println(
				no + "번 데이터가 존재하지 않습니다.");
			return;
		}
		System.out.print("변경할 제목을 입력하세요 : ");
		board.setTitle(sc.nextLine());
		System.out.print("변경할 내용을 입력하세요 : ");
		board.setContent(sc.nextLine());
		dao.updateBoard(board);
		System.out.println("게시글이 수정되었습니다.");
	}
}
