package board.step06;

import board.step06.ui.BoardUI;

public class Test {
	public static void main(String[] args) {
		new BoardUI().service();
	}
}







