package board.step05;

import board.step05.ui.BoardUI;

public class Test {
	public static void main(String[] args) {
		new BoardUI().service();
	}
}







