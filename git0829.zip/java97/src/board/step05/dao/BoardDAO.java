/*
 *  insert모듈명, update모듈명, delete모듈명, select모듈명
 *  
 *  등록 : Create
 *  조회 : Read
 *  수정 : Update
 *  삭제 : Delete
 */
package board.step05.dao;

import board.step05.vo.Board;
import util.MyArrayList;

public class BoardDAO {
	// 글번호 처리 
	int no = 0;
	// 데이터 관리
	MyArrayList list = new MyArrayList();
	
	public MyArrayList selectBoard() {
//		System.out.println(list);
		return list;
	}
	public Board selectBoardByNo(int no) {
		for (int i = 0; i < list.size(); i++) {
			Board b = (Board)list.get(i);
			if (no == b.getNo()) {
				return b;
			}
		}
		return null;
	}
	public void insertBoard(Board board) {
		board.setNo(++no);
		list.add(board);
	}
	public void updateBoard(Board board) {
		for (int i = 0; i < list.size(); i++) {
			Board b = (Board)list.get(i);
			if (board.getNo() == b.getNo()) {
				list.set(i, board);
				return ;
			}
		}
	}
	public boolean deleteBoard(int no) {
		int delNo = -1;
		for (int i = 0; i < list.size(); i++) {
			Board board = (Board)list.get(i);
			if (no == board.getNo()) {
				delNo = i;
				break;
			}
		}
		
		if (delNo == -1) {
			return false;
		}
		
		list.remove(delNo);
		return true;
	}
}








