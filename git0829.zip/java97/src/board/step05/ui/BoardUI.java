package board.step05.ui;

import java.util.Scanner;

import board.step06.dao.BoardDAO;
import board.step06.vo.Board;
import util.MyArrayList;

public class BoardUI {
	private Scanner sc = new Scanner(System.in);
	private BoardDAO dao = new BoardDAO();
	
	public void showList() {
		MyArrayList list = dao.selectBoard();
		
		System.out.println("------------------------");
		System.out.println("번호\t제목\t글쓴이");
		System.out.println("------------------------");
		for (int i = list.size() - 1; i >= 0; i--) {
			Board b = (Board)list.get(i);	
			System.out.println(
				b.getNo() + "\t" + 
				b.getTitle() + "\t" + 
				b.getWriter()
			);
		}
		// 데이터가 존재하지 않는 경우
		if (list.isEmpty()) {
			System.out.println("게시글이 존재하지 않습니다.");
		}
		System.out.println("------------------------");
	}
	
	public void showBoard() {
		System.out.print("조회할 글번호를 입력하세요 : ");
		int no = Integer.parseInt(sc.nextLine());
		System.out.println("---------------------------");
		
		Board b = dao.selectBoardByNo(no);
		if (b != null) {
			System.out.println("번호 : " + b.getNo());
			System.out.println("제목 : " + b.getTitle());
			System.out.println("글쓴이 : " + b.getWriter());
		}
		else {
			System.out.println(
					no + "번에 해당하는 데이터가 없습니다.");
		}
		System.out.println("---------------------------");
	}	
	
	public void writeBoard() {
		Board b = new Board();
		System.out.print("제목을 입력하세요 : ");
		b.setTitle(sc.nextLine());
		System.out.print("글쓴이를 입력하세요 : ");
		b.setWriter(sc.nextLine());
		dao.insertBoard(b);
		System.out.println("게시글 등록이 완료되었습니다.");
	}
	
	public void modBoard() {
		System.out.print("수정할 글번호를 입력하세요 : ");
		int no = Integer.parseInt(sc.nextLine());
		Board board = dao.selectBoardByNo(no);
		if (board == null) {
			System.out.println(
				no + "번 데이터가 존재하지 않습니다.");
			return;
		}
		System.out.print("변경할 제목을 입력하세요 : ");
		board.setTitle(sc.nextLine());
		dao.updateBoard(board);
		System.out.println("게시글이 수정되었습니다.");
	}
	
	public void delBoard() {
		System.out.print("삭제할 글번호를 입력하세요 : ");
		int no = Integer.parseInt(sc.nextLine());
		boolean result = dao.deleteBoard(no);
		if (result) {
			System.out.println("게시글이 삭제되었습니다.");
		}
		else {
			System.out.println(
					no + "번 데이터가 존재하지 않습니다.");
		}
	}
	
	public int choiceMenu() {
		System.out.println("-------------------------");
		System.out.println("1. 전체 게시물 조회");
		System.out.println("2. 글번호 조회");
		System.out.println("3. 글등록");
		System.out.println("4. 글수정");
		System.out.println("5. 글삭제");
		System.out.println("0. 종료");
		System.out.println("-------------------------");
		System.out.print("메뉴 중 처리할 항목을 선택하세요 : ");
		return Integer.parseInt(sc.nextLine());
	}
	
	public void exitBoard() {
		System.exit(0);
	}
	
	public void service() {
		while (true) {
			switch (choiceMenu()) {
			case 1: showList(); break;
			case 2: showBoard(); break;
			case 3: writeBoard(); break;
			case 4: modBoard(); break;
			case 5: delBoard(); break;
			case 0: exitBoard(); 
			}
		}		
	}
}
