package board.step02;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		// 데이터 저장 위치
		int pos = 0;
		// 글번호 처리 
		int no = 0;
		
		// 게시글의 데이터를 저장하기 위한 배열 선언
		String[] titleArr = new String[5];
		String[] writerArr = new String[5];
		int[] noArr = new int[5];
		
		Scanner sc = new Scanner(System.in);
		outer : 
		while (true) {
			System.out.println("-------------------------");
			System.out.println("1. 전체 게시물 조회");
			System.out.println("2. 글번호 조회");
			System.out.println("3. 글등록");
			System.out.println("4. 글수정");
			System.out.println("5. 글삭제");
			System.out.println("0. 종료");
			System.out.println("-------------------------");
			System.out.print("메뉴 중 처리할 항목을 선택하세요 : ");
			int menu = Integer.parseInt(sc.nextLine());
			switch (menu) {
			case 1:
				System.out.println("------------------------");
				System.out.println("번호\t제목\t글쓴이");
				System.out.println("------------------------");
				for (int i = pos - 1; i >= 0; i--) {
					System.out.println(
						noArr[i] + "\t" + 
						titleArr[i] + "\t" + 
						writerArr[i] 
					);
				}
				// 데이터가 존재하지 않는 경우
				if (pos == 0) {
					System.out.println("게시글이 존재하지 않습니다.");
				}
				System.out.println("------------------------");
				break;
			case 2:
				System.out.print("조회할 글번호를 입력하세요 : ");
				int searchNo = Integer.parseInt(sc.nextLine());
				System.out.println("---------------------------");
				
				boolean isExist = false;
				for (int i = 0; i < pos; i++) {
					if (searchNo == noArr[i]) {
						isExist = true;
						
						System.out.println("번호 : " + noArr[i]);
						System.out.println("제목 : " + titleArr[i]);
						System.out.println("글쓴이 : " + writerArr[i]);
						
						break;
					}
				}
				
				// 사용자가 요청한 글번호에 해당하는 데이터가 없는 경우
				if (isExist == false) {
					System.out.println(
							searchNo + "번에 해당하는 데이터가 없습니다.");
				}
				System.out.println("---------------------------");
				System.out.println("글번호 조회 메뉴 선택함");
				break;
			case 3:
				// 배열에 데이터가 다 차게 되면 공간을 확장
				if (noArr.length == pos) {
					String[] tempTitleArr = new String[pos * 2];
					String[] tempWriterArr = new String[pos * 2];
					int[] tempNoArr = new int[pos * 2];
					
					System.arraycopy(titleArr, 0, tempTitleArr, 0, pos);
					System.arraycopy(writerArr, 0, tempWriterArr, 0, pos);
					System.arraycopy(noArr, 0, tempNoArr, 0, pos);
					
					titleArr = tempTitleArr;
					writerArr = tempWriterArr;
					noArr = tempNoArr;
				}
				
				System.out.print("제목을 입력하세요 : ");
				titleArr[pos] = sc.nextLine();
				System.out.print("글쓴이를 입력하세요 : ");
				writerArr[pos] = sc.nextLine();
				// 글번호 저장
				noArr[pos] = ++no;
				
				pos++;
				
				System.out.println("게시글 등록이 완료되었습니다.");
				break;
				
			case 4:
				/*
				 *   수정할 글번호를 입력하세요 : 3
				 *   3번 데이터가 존재하지 않습니다.
				 *   
				 *   변경할 제목을 입력하세요 : 홍길동
				 *   게시글이 수정되었습니다.
				 */
				System.out.print("수정할 글번호를 입력하세요 : ");
				int modFindNo = Integer.parseInt(sc.nextLine());
				int modNo = -1;
				for (int i = 0; i < pos; i++) {
					if (modFindNo == noArr[i]) {
						modNo = i;
						break;
					}
				}
				
				if (modNo == -1) {
					System.out.println(
						modFindNo + "번 데이터가 존재하지 않습니다.");
					break;
				}
				
				System.out.print("변경할 제목을 입력하세요 : ");
				titleArr[modNo] = sc.nextLine();
				System.out.println("게시글이 수정되었습니다.");
				break;
			case 5:
				/*
				 *   삭제할 글번호를 입력하세요 : 3
				 *   3번 데이터가 존재하지 않습니다.
				 *   
				 *   변경할 제목을 입력하세요 : 홍길동
				 *   게시글이 수정되었습니다.
				 */				
				System.out.print("삭제할 글번호를 입력하세요 : ");
				int delFindNo = Integer.parseInt(sc.nextLine());
				int delNo = -1;
				for (int i = 0; i < pos; i++) {
					if (delFindNo == noArr[i]) {
						delNo = i;
						break;
					}
				}
				
				if (delNo == -1) {
					System.out.println(
						delFindNo + "번 데이터가 존재하지 않습니다.");
					break;
				}
				
				// 삭제 처리
				// 1번과정 : 삭제할 글의 인덱스 찾기 : delNo
				// 2번과정 : 앞으로 몇개의 데이터를 당겨야 할지..
				// 3번과정 : pos의 데이터수 하나 줄이기
				// 4번과정 : 마지막 데이터 초기화
				int moveCnt = pos - 1 - delNo;
				if (moveCnt > 0) {
					System.arraycopy(noArr, delNo + 1, noArr, delNo, moveCnt);
					System.arraycopy(titleArr, delNo + 1, titleArr, delNo, moveCnt);
					System.arraycopy(writerArr, delNo + 1, writerArr, delNo, moveCnt);
				}
				
				pos--;
				
				noArr[pos] = 0;
				titleArr[pos] = null;
				writerArr[pos] = null;

				System.out.println("게시글이 삭제되었습니다.");
				break;
			case 0:
				System.out.println("게시판 프로그램을 종료합니다.");
				break outer;
			}
			
		}
	}
}







