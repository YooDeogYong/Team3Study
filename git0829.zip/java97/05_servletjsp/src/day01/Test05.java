// 응답과 관련된 서블릿
package day01;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/day01/test05")
public class Test05 extends GenericServlet {
	@Override
	public void service(
				ServletRequest request, ServletResponse response
			) throws ServletException, IOException {
		// 사용자 브라우져에게 전송하는 데이터(컨텐트)의 타입을 알려준다.
		response.setContentType("text/html; charset=utf-8");
		
		// 사용자에게 데이터를 전송하기 위해서 출력스트림 얻기
//		response.getOutputStream();  // 이미지 등.. 바이트 데이터 전송시
		PrintWriter out = response.getWriter(); // 일반 텍스트 데이터를 전송
		// 데이터 출력하기
		out.println("<html>");
		out.println("  <body><h1>성공</h1></body>");
		out.println("</html>");
		// 출력스트림 닫기
		out.close();
	}
}












