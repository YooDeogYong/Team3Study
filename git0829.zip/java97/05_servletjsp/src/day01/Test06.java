package day01;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/day01/test06")
public class Test06 extends GenericServlet {

	@Override
	public void service(
			ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		/*
		 *  http://localhost:8000/05_servletjsp/day01/test06
		 *  http://localhost:8000/05_servletjsp/day01/test06?id=java97
		 *  http://localhost:8000/05_servletjsp/day01/test06
		 *  ?id=java97&hobby=music&hobby=movie
		 */
		String id = request.getParameter("id");
		System.out.println("id : " + id);
		String hobby = request.getParameter("hobby");
		System.out.println("hobby : " + hobby);
		String[] hobbys = request.getParameterValues("hobby");
		System.out.println("hobbys : " + Arrays.toString(hobbys));
	}
}

















