package day01;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/day01/test10")
public class Test10 extends HttpServlet {

	@Override
	protected void service(
			HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getMethod();
		if (method.equals("POST")) {
			request.setCharacterEncoding("utf-8");
		}
		System.out.println("method : " + method);
		String uri = request.getRequestURI();
		System.out.println("uri : " + uri);
		
		response.setContentType("text/html; charset=utf-8");
		
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<body>");
		out.println("	<table border='1'>");
		out.println("	<tr>");
		out.println("		<td>method</td>");
		out.println("		<td>" + method + "</td>");
		out.println("	</tr>");
		out.println("	<tr>");
		out.println("		<td>uri</td>");
		out.println("		<td>" + uri + "</td>");
		out.println("	</tr>");
		out.println("	<tr>");
		out.println("		<td colspan='2'>");
		out.println("		  <a href='/05_servletjsp/day01/test09.html'>뒤로가기</a>");
		out.println("		</td>");
		out.println("	</tr>");
		out.println("	</table>");
		out.println("</body>");
		out.println("</html>");
		
		out.close();
	}
	
}















