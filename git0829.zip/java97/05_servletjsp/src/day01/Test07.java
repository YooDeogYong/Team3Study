package day01;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/day01/test07")
public class Test07 extends GenericServlet {
	@Override
	public void service(ServletRequest request, ServletResponse arg1) throws ServletException, IOException {
		System.out.println("서블릿 호출 성공됨....");
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		
		Test07VO vo = new Test07VO();
		vo.setId(id);
		vo.setName(name);
		vo.setPassword(password);
		vo.setEmail(email);
		
		Test07DAO dao = new Test07DAO();
		dao.insertMember(vo);
		
		System.out.println("id : " + id);
		System.out.println("password : " + password);
		System.out.println("name : " + name);
		System.out.println("email : " + email);
	}
}












