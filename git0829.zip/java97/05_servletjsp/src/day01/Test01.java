/*
 *      서버에서 동작하는 자바 -> 서블릿
 *      
 *      서블릿으로 인식되기 위해서 반드시 Servlet 인터페이스 타입이 되어야 한다.
 * 
 * 		사용자가 최초 요청시  
 *      init() -> service() 실행됨..
 *      
 *      이후 요청시에는
 *      service() 실행됨.. 
 *      
 *      web.xml에 설정을 통해서 URI 와 Servlet 를 연결하는 방법
 *      http://localhost:8000/05_servletjsp/day01/test01	
 */
package day01;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Test01 implements Servlet {
	
	// 서블릿이 메모리에서 해제 될때 서버가 자동 호출하는 메서드
	@Override
	public void destroy() {
		
	}

	// 서블릿에 대한 설정과 연관된 객체(ServletConfig)를 얻을수 있는 메서드
	@Override
	public ServletConfig getServletConfig() {
		return null;
	}

	// 서블릿에 대한 간단한 설명 : 관리자 페이지에서 주로 사용
	@Override
	public String getServletInfo() {
		return null;
	}

	// 서블릿이 서버의 메모리에 로딩될때 최초 한번만 호출 되는 메서드
	// 객체 생성이 한번만 발생한다.(new)
	@Override
	public void init(ServletConfig arg0) throws ServletException {
		System.out.println("init 호출");
	}

	// 사용자가 요청할 때 마다 호출되는 메서드
	@Override
	public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
		System.out.println("service 호출");
	}
}





















