/*    Servlet   - abstract init(ServletConfig)
 *              - abstract service(ServletRequest, ServletResponse)	
 *    GenericServlet  
 *    			- 1. init(ServletConfig)
 *              - abstract service(ServletRequest, ServletResponse)
 *    HttpServlet     
 *              - 2. service(ServletRequest, ServletResponse)
 *                아래의 service 메서드 호출 
 *              - 3. service(HttpServletRequest, HttpServletResponse)
 *                GET 방식의 요청이 오면 doGet 호출
 *                POST 방식의 요청이 오면 doPost 호출
 *    Test08    - 4. init(ServletConfig)
 *              - 5. service(ServletRequest, ServletResponse)      
 *              - 6. service(HttpServletRequest, HttpServletResponse)
 *              - 7. doGet(HttpServletRequest, HttpServletResponse)
 *              - 8. doPost(HttpServletRequest, HttpServletResponse)
 */ 
package day01;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/day01/test08")
public class Test08 extends HttpServlet {
	/*
	public void service(
			ServletRequest request, ServletResponse response)
			throws ServletException, IOException {
		System.out.println("service(1)");
	}
	public void service(
			HttpServletRequest request, HttpServletResponse response)
					throws ServletException, IOException {
		System.out.println("service(2)");
	}
	 */
	public void doGet(
			HttpServletRequest request, HttpServletResponse response)
					throws ServletException, IOException {
		System.out.println("doGet()");
	}
	public void doPost(
			HttpServletRequest request, HttpServletResponse response)
					throws ServletException, IOException {
		System.out.println("doPost()");
	}
}


















