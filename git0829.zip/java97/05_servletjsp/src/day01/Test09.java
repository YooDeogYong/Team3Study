package day01;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/day01/test09")
public class Test09 extends HttpServlet {

	@Override
	protected void doPost(
			HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// post 방식 요청일 경우 파라미터 한글이 깨진는 현상이 발생함
		// 한글처리를 위해서 다음과 같이 코드를 추가한다.
		request.setCharacterEncoding("utf-8");
		
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		
		System.out.println(id);
		System.out.println(password);
		System.out.println(name);
		System.out.println(email);
	}
	
}









