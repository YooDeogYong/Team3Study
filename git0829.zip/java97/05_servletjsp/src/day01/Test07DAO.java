/*
create table t_member (
    id varchar2(30) primary key,
    name varchar2(30) not null,
    email varchar2(30) not null,
    password varchar2(8) not null
);

select * from t_member;
 */
package day01;

import java.sql.Connection;
import java.sql.PreparedStatement;

import kr.co.mlec.util.ConnectionPool;
import kr.co.mlec.util.JdbcUtil;

public class Test07DAO {
	public void insertMember(Test07VO vo) {
		Connection con = null;
		PreparedStatement stmt = null; 
		try {
			con = ConnectionPool.getConnection();
			
			StringBuffer sql = new StringBuffer();
			sql.append("insert into t_member (id, name, password, email) ");
			sql.append("values(?, ?, ?, ?) ");
			stmt = con.prepareStatement(sql.toString());
			
			int index = 1;
			stmt.setString(index++, vo.getId());
			stmt.setString(index++, vo.getName());
			stmt.setString(index++, vo.getPassword());
			stmt.setString(index++, vo.getEmail());
			
			int cnt = stmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(stmt);
			ConnectionPool.releaseConnection(con);
		}
	
	}
}
