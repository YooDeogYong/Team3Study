package net05.webserver;

public class Test04Sub {
	public static void main(String[] args) {
		String line = "GET /test/login.jsp?id=1111&pass=1234 HTTP/1.1";
		String[] arr = line.split(" ");
		System.out.println("요청메서드 : " + arr[0]);
		System.out.println("요청URI : " + arr[1]);
		
		String[] uArr = arr[1].split("\\?");
		System.out.println("URI : " + uArr[0]);
		System.out.println("QueryString : " + uArr[1]);
		
		String[] pArr = uArr[1].split("&");
		for (String parameter : pArr) {
//			System.out.println(parameter);
			String[] paramArr = parameter.split("=");
			System.out.println("파라미터명 : " + paramArr[0]);
			System.out.println("파라미터값 : " + paramArr[1]);
		}
	}
}










