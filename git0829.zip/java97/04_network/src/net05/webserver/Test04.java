package net05.webserver;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class Test04 {	
	public static void main(String[] args) {
		try {
			ServerSocket server = new ServerSocket(8000);
			while (true) {
				Socket client = server.accept();
				// 요청 처리 부분(클라이언트 -> 서버)
				InputStream in = client.getInputStream();
				InputStreamReader isr = new InputStreamReader(in);
				BufferedReader br = new BufferedReader(isr);
				
				// 요청의 첫번째 줄(시작라인)
				String reqStartLine = br.readLine();
				System.out.println("요청라인 : " + reqStartLine);
				// GET /test.jsp HTTP/1.1
				String[] arr = reqStartLine.split(" ");
				String[] uArr = arr[1].split("\\?");
				
				String uri = uArr[0];
				Map<String, String> pMap = new HashMap<>();
				if (uArr.length == 2) {	
					String[] pArr = uArr[1].split("&");
					for (String parameter : pArr) {
						String[] paramArr = parameter.split("=");
						pMap.put(paramArr[0], paramArr[1]);
					}
				}
				String result = "";
				switch (uri) {
				case "/idDupCheck.jsp":
					result = "아이디 중복 체크 요청함";
					String id = pMap.get("id");
					if (id == null) {
						result = "아이디 파라미터가 없습니다.";
					}
					break;
				case "/passFind.jsp":
					result = "패스워드 찾기 요청함";
					break;
				default:
					result = "요청페이지는 존재하지 않습니다.";
				}
				
				
				
				
				
				
				
				
				
				
				
				
				String reqHeaders = "";
				// 요청헤더 추출하기
				while (true) {
					String line = br.readLine();
					if (line.equals("")) {
						break;
					}
					reqHeaders += line + "<br>";
				}
				
				// 응답 처리 부분(서버 -> 클라이언트)
				String msg = "<html><body>" 
				           + "<h2>" + result + "</h2>"
				           + "</body></html>";

				String startLine = "HTTP/1.1 200 OK\r\n";
				String headers = "Content-Type: text/html; charset=utf-8\r\n"
						       + "Content-Length: " + msg.getBytes().length + "\r\n\r\n";
				
				String data = startLine + headers + msg;
				
				OutputStream out = client.getOutputStream();
				out.write(data.getBytes());
				out.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}






