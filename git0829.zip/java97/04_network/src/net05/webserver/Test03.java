package net05.webserver;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Test03 {	
	public static void main(String[] args) {
		try {
			ServerSocket server = new ServerSocket(8000);
			while (true) {
				Socket client = server.accept();
				// 요청 처리 부분(클라이언트 -> 서버)
				InputStream in = client.getInputStream();
				InputStreamReader isr = new InputStreamReader(in);
				BufferedReader br = new BufferedReader(isr);
				
				// 요청의 첫번째 줄(시작라인)
				String reqStartLine = br.readLine();
				System.out.println("요청라인 : " + reqStartLine);
				
				String reqHeaders = "";
				// 요청헤더 추출하기
				while (true) {
					String line = br.readLine();
					if (line.equals("")) {
						break;
					}
					
					reqHeaders += line + "<br>";
				}
				
				// 응답 처리 부분(서버 -> 클라이언트)
				String msg = "<html><body>" 
				           + "<h2>" + reqStartLine + "</h2>"
				           + "<h2>HEADER</h2>"
				           + "<h2>" + reqHeaders + "</h2>"
				           + "</body></html>";

				String startLine = "HTTP/1.1 200 OK\r\n";
				String headers = "Content-Type: text/html; charset=utf-8\r\n"
						       + "Content-Length: " + msg.getBytes().length + "\r\n\r\n";
				
				String data = startLine + headers + msg;
				
				OutputStream out = client.getOutputStream();
				out.write(data.getBytes());
				out.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}






