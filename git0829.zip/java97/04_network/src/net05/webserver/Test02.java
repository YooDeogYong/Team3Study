package net05.webserver;

import java.io.FileReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Test02 {
	public static String getHtml() throws Exception {
		StringBuffer data = new StringBuffer();
		FileReader fr = new FileReader("src/net05/webserver/test06.html");
		
		while (true) {
			int ch = fr.read();
			if (ch == -1) {
				break;
			}
			data.append((char)ch);
		}
		fr.close();
		return data.toString();
	}
	
	public static void main(String[] args) {
		try {
			ServerSocket server = new ServerSocket(8000);
			while (true) {
				Socket client = server.accept();
				System.out.println("접속 사용자 : " + client);
				// 사용자에게 정보를 전송하기 위한 출력 객체 얻기
				// 네트워크 사용하기 위해서 바이트 단위 출력 사용
				
				// 전송할 내용
				// HTTP 약속 형식으로 전송해야 함
				// 시작라인 + 헤더 + 바디
				String msg = "<html><body>" 
				           + getHtml()
				           + "</body></html>";

				String startLine = "HTTP/1.1 200 OK\r\n";
				String headers = "Content-Type: text/html; charset=utf-8\r\n"
						       + "Content-Length: " + msg.getBytes().length + "\r\n\r\n";
				
				String data = startLine + headers + msg;
				
				OutputStream out = client.getOutputStream();
				out.write(data.getBytes());
				out.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}






