package net05.webserver;

import java.net.ServerSocket;
import java.net.Socket;

public class Test01 {
	public static void main(String[] args) {
		// 서버 역활을 담당하는 소켓 클래스
		// 소켓의 종류 : tcp(ServerSocket), udp
		try {
			// 서버 생성 : 8000번 포트를 활용
			ServerSocket server = new ServerSocket(8000);
			
			// 클라이언트의 접속 요청을 대기하라..
			// accept 메서드를 실행 시 프로그램 일시 멈춤..
			// 클라이언트가 서버에 접속하게 되는 순간 프로그램 진행됨..
			while (true) {
				System.out.println("서버 클라이언트 요청 대기중");
				Socket client = server.accept();
				System.out.println("클라이언트 : " + client);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}










