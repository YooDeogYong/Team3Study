package net.quiz;

import java.util.List;

import net03.json.Member;

class Quiz02Sub {
	private String info;
	private List<Member> students;
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public List<Member> getStudents() {
		return students;
	}
	public void setStudents(List<Member> students) {
		this.students = students;
	}
}

public class Quiz02 {
	public static void main(String[] args) {
		String data = "";
		data = "{"
			 + "   'info': '학생들의 정보', "
		     + "   'students': [ "
		     + "                  {'name': '홍길동', 'age': 22},"
		     + "                  {'name': '이영지', 'age': 25}"
		     + "               ] "
		     + "}";
	}
}







