package net.quiz;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Quiz01 {
	public static void main(String[] args) {
		try {
			DocumentBuilderFactory factory = 
					DocumentBuilderFactory.newInstance();
			DocumentBuilder parser = factory.newDocumentBuilder();
			Document doc = parser.parse("src/net/quiz/daum.xml");
			NodeList list = doc.getElementsByTagName("item");
			for (int i = 0; i < list.getLength(); i++) {
				Node node = list.item(i);
				NodeList cList = node.getChildNodes();
				for (int k = 0; k < cList.getLength(); k++) {
					Node cNode = cList.item(k);
					String cName = cNode.getNodeName();
					switch (cName) {
					case "pubDate":
					case "title":
					case "link":
						System.out.println(
							cName + " : " + cNode.getTextContent() 
						);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}










