package net02.xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Test02 {
	public static void main(String[] args) {
		try {
			DocumentBuilderFactory factory = 
					DocumentBuilderFactory.newInstance();
			DocumentBuilder parser = factory.newDocumentBuilder();
			Document doc = parser.parse("src/net02/xml/data2.xml");
			NodeList list = doc.getElementsByTagName("family");
			int len = list.getLength();
			System.out.println("family 엘리먼트 수 : " + len);
			for (int i = 0; i < len; i++) {
				// family 에 대한 엘리먼트
				Node node = list.item(i);
//				System.out.println(node.getNodeName());
				
				NodeList cList = node.getChildNodes();
				System.out.println(
						"family 의 자식 노드 수 : " + cList.getLength() 
				);
				for (int k = 0; k < cList.getLength(); k++) {
					Node cNode = cList.item(k);
					String cName = cNode.getNodeName();
					if (cName.equals("#text")) {
						continue;
					}
					System.out.println(cName + " - " + cNode.getTextContent());
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}












