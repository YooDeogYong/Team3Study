package net02.xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Test01 {
	public static void main(String[] args) {
		// xml 문서의 내용을 파싱 : DOM 방식 파서 활용
		// data1.xml 파일의 내용 파싱
		// Dom 파서 : DocumentBuilder
		try {
			// 1단계 파서를 얻는 과정
			// Dom 파서를 생성하는 Factory 객체 얻기
			DocumentBuilderFactory factory = 
					DocumentBuilderFactory.newInstance();
			// Dom 파서 객체 얻기
			DocumentBuilder parser = factory.newDocumentBuilder();
			
			// 2단계 : 생성된 파서를 이용해서 xml 문서의 내용을 파싱
			Document doc = parser.parse("src/net02/xml/data1.xml");
			
			// 3단계 : Document 객체를 활용한 데이터 추출
			NodeList list = doc.getElementsByTagName("family");
			int len = list.getLength();
			System.out.println("family 엘리먼트 수 : " + len);
			for (int i = 0; i < len; i++) {
				Node node = list.item(i);
				System.out.println(node.getNodeName());
				System.out.println(node.getTextContent());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}












