// jsoup 라이브러리를 이용한 html 파싱하기
/*
 *    이름  :  태그명
 *    .이름 : class="이름"
 *    #이름 : id="이름"
 *    이름.이름 : <이름 class="이름">
 *    A이름  B이름 : A 엘리먼트 밑에 있는 모든 B엘리먼트 선택 
 *    A이름  > B이름 : A 엘리먼트 밑에 있는 직계 자식 B엘리먼트 선택 
 */
package net04.crawling;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Test01 {
	public static void main(String[] args) {
		String html = "<html>"
				    + "  <head>"
				    + "  	<title>CRAWLING 연습</title>"
				    + "  </head>"
				    + "  <body>"
				    + "     <p>Parse HTML</p>"
				    + "     <p class='b'>class 를 적용한 p</p>"
				    + "     <p id='a'>"
				    + "     	연습..."
				    + "     </p>"
				    + "     <div>div 엘리먼트</div>"
				    + "     <div class='b'>클래스 접근</div>"
				    + "     <div class='c'>"
				    + "     	<a href='http://www.naver.com'>"
				    + "     		네이버"
				    + "     	</a>"
				    + "     	<div>"
				    + "     		<a href='#'>자식의 자식</a>"
				    + "     	</div>"
				    + "     </div>"
				    + "     <a href='#'>테스트</a>"
				    + "  </body>"
				    + "</html>";
		Document doc = Jsoup.parse(html);
		
		// 태그를 이용한 p 엘리먼트 접근하기
//		Elements elements = doc.select("p");
		// id가 a인 엘리먼트 접근
		// id="a"
		Elements elements = doc.select("div.c > a");
		
		int len = elements.size();
		for (Element e : elements) {
			System.out.println(e.html());
		}
		
		// DIV 엘리먼트의 내용 출력하기
		// 클래스 속성을 이용한 접근 : .클래스명
		// class="b"
//		elements = doc.select(".b");
		// <div class="b">
		elements = doc.select("div.b");
		for (Element e : elements) {
			System.out.println(e.html());
		}
	}
}











