package net01.url;

import java.net.MalformedURLException;
import java.net.URL;

public class Test01 {
	public static void main(String[] args) {
		String addr = "http://www.naver.com:8080/mypage.do?id=hong";
		try {
			URL url = new URL(addr);
			System.out.println(url.getProtocol());
			System.out.println(url.getHost());
			System.out.println(url.getPort());
			System.out.println(url.getFile());
			System.out.println(url.getPath());
			System.out.println(url.getQuery());
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
}













