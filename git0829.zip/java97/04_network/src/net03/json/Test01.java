// http://mvnrepository.com/  - 라이브러리 다운로드 
package net03.json;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

public class Test01 {
	private static void test01() {
		Member m = new Member();
		m.setName("홍길동");
		m.setAge(22);
		
		// json 형태의 문자열로 변환
		String jsonData = "";
		jsonData += "{";
		jsonData += "	\"name\": \"" + m.getName() + "\",";
		jsonData += "	\"age\": " + m.getAge();	
		jsonData += "}";
		System.out.println(jsonData);
	}

	private static void test02() {
		Member m = new Member();
		m.setName("홍길동");
		m.setAge(22);
		
		// json 형태의 문자열로 변환
		/*
		Gson gson = new Gson();
		String jsonData = gson.toJson(m);
		System.out.println(jsonData);
		*/
		
		System.out.println(new Gson().toJson(m));
	}
	
	private static void test03() {
		Member m = new Member();
		m.setName("홍길동");
		m.setAge(22);

		List<String> hobbys = new ArrayList<>();
		hobbys.add("축구");
		hobbys.add("사이클");
		hobbys.add("야구");
		m.setHobbys(hobbys);
		
		System.out.println(new Gson().toJson(m));
	}

	private static void test04() {
		Address addr = new Address();
		addr.setPostNo("789-123");
		addr.setBasic("서울 서초구 비트별관");
		addr.setDetail("6층 604호");
		System.out.println(new Gson().toJson(addr));
		
		Member m = new Member();
		m.setAddr(addr);
		
		m.setName("홍길동");
		m.setAge(22);
		
		List<String> hobbys = new ArrayList<>();
		hobbys.add("축구");
		hobbys.add("사이클");
		hobbys.add("야구");
		m.setHobbys(hobbys);
		
		System.out.println(new Gson().toJson(m));
	}
	
	private static void test05() {
		String data = 
				"{'name': '홍길동', 'age': 33, 'hobbys': ['a', 'b']}";
		Member m = new Gson().fromJson(data, Member.class);
		System.out.println(m.getName());
		System.out.println(m.getAge());
		List<String> hobbys = m.getHobbys();
		for (String hobby : hobbys) {
			System.out.println(hobby);
		}
	}
	
	public static void main(String[] args) {
		// 객체의 내용을 JSON 형태의 문자열로 변환하는 예제
//		test01();
//		test02();
//		test03();
//		test04();
		
		// JSON 형태의 문자열의 내용을 객체로 변환하기
		test05();
	}
}

















