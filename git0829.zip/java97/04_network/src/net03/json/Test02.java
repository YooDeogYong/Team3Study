package net03.json;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

public class Test02 {
	public static void main(String[] args) {
		try {
			String addr = "https://apis.daum.net/search/knowledge";
			String param = "?apikey=3c9c1fa0e1b7288504129a9b0b5f8fc5&q=java&output=json";
			URL url = new URL(addr + param);
			InputStream in = url.openStream();
			InputStreamReader isr = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(isr);
			while (true) {
				String line = br.readLine();
				if (line == null) break;
				
				System.out.println(line);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
